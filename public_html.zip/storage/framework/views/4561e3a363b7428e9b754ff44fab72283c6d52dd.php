<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>daliy Report</title>
    <link href="https://fonts.googleapis.com/css?family=Mirza" rel="stylesheet">
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/forms.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/form/blackStyle-them.css">
    <link href="../css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body style="padding-top: 70px">
<section class="option-box" style="top: 0">
    <div class="color-option">
        <h4>Color option</h4>
        <ul class="list-unstyled">
            <li style="background:#000" data-value="../css/form/blackStyle-them.css"></li>
            <li data-value="../css/form/pinkStyle-them.css"></li>
            <li data-value="../css/form/blueStyle-them.css"></li>
            <li data-value="../css/form/seaStyle-them.css"></li>
            <li data-value="../css/form/greenStyle-them.css"></li>
            <li data-value="../css/form/violetStyle-them.css"></li>
        </ul>
    </div>
    <i class="fa fa-gear fa-3x gear-ch" style="padding: 6px"></i>
</section>
<form>
    <div class="fixed-top">
        <input type="text" class="search form-control" placeholder="You Looking For What.....">
    </div>
</form>



<section>
    <?php for($i=0; $i<100; $i++): ?>

        <table class="table text-center table-striped ">
            <thead class="thead-inverse table-h<?php echo e($i); ?> wow flipInX" data-wow-delay="1s" >
            <tr>

                <th colspan="3">sunday</th>
                <th>15/10/2010</th>
                <th>Dr/mohamed Ahmed</th>
                <th colspan="2"> Evening Daily Work Programing</th>


            </tr>
            </thead>
            <thead class=" table-nh table-he<?php echo e($i); ?>">
            <tr>
                <th>#</th>
                <th> التاريخ </th>
                <th> اليوم </th>
                <th> موقع </th>
                <th> صيدلية </th>
                <th> الوقت </th>
                <th> ملاحطات </th>



            </tr>
            </thead>
            <tbody class=" table-nb table-bd<?php echo e($i); ?>">

            <tr>
                <th scope="row">1</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td>@twitter</td>
                <td>@twitter</td>
                <td>@twitter</td>
            </tr>



            </tbody>
        </table>
    <?php endfor; ?>
</section>

<script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src='<?php echo e(asset('js/jquery-2.2.2.min.js')); ?>'></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
<script src="../js/jquery.nicescroll.min.js"></script>
<script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
<script>
    new WOW().init();
</script>
<script  src="../js/myjs.js" type="text/javascript">  </script>

<script>
    $(document).ready(function () {
        $('.table-nh,.table-nb').fadeOut();
    });

    <?php for($i=0;$i<100;$i++): ?>

    $('.table-h<?php echo e($i); ?>').click(function () {
        $('.table-he<?php echo e($i); ?>,.table-bd<?php echo e($i); ?>').fadeToggle();
    });
    <?php endfor; ?>

</script>
</body>
</html>