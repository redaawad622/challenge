<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="statistic  align-items-center bg-white has-shadow" id="promotion">


        <h3>Administer Database Backups</h3>

         <a id="create-new-backup-button" href="<?php echo e(url('/admin/BackUp/create')); ?>" class="btn btn-primary pull-right"
               style="margin-bottom:2em;"><i
                        class="fa fa-plus"></i> Create New Backup
            </a>
            <?php if(count($backups)): ?>

                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>File</th>
                        <th>Size</th>
                        <th>Date</th>
                        <th>Age</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($backup['file_name']); ?></td>
                            <td><?php echo e(App\Helper\AppHelper::instance()->human_filesize($backup['file_size'])); ?></td>
                            <td>
                                <?php echo e(date('F jS, Y, g:ia (T)',$backup['last_modified'])); ?>

                            </td>
                            <td>
                                <?php echo e(App\Helper\AppHelper::instance()->diff_time($backup['last_modified'],time())); ?>

                            </td>
                            <td class="text-right">
                                <a class="btn btn-xs btn-default"href="/admin/BackUp/download/<?php echo e($backup['file_name']); ?>">

                                    <i class="fa fa-cloud-download"></i> Download
                                </a>
                                <a class="btn btn-xs btn-danger" data-button-type="delete" href="/admin/BackUp/delete/<?php echo e($backup['file_name']); ?>">
                                   <i class="fa fa-trash-o"></i>
                                    Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="well" style="text-align: center ; padding: 50px;">
                    <h4>There are no backups</h4>
                </div>
            <?php endif; ?>
    </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>