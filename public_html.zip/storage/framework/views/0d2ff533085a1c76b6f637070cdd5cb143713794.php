<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=877">
    <title>My Website</title>
    <link href="https://fonts.googleapis.com/css?family=Arimo" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/normalize.min.css')); ?>">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/hover.css')); ?>">

    <link href="<?php echo e(asset('css/font-awesome.css')); ?>" rel="stylesheet">
    <style>
        body
        {
            font-family: 'Arimo', sans-serif;
            color: #343434;
        }
        .pref
        {
            background-color: #05998D;
            color: #fff;
        }
        h1{
            font-weight: bold;
        }
        .content,.content-2
        {
            padding-left: 20px;
            padding-right: 40px;
            padding-top: 20px;
        }
        .content .name
        {
            margin-bottom: 40px;
        }
       .info .info-h,.skill .skill-h
        {
            background-color: #017C73;
            width: 100%;
            padding: 5px 5px 1px 20px;


        }
        .info .email,.skill .skill-o
        {
            padding: 20px 40px 20px 20px;
        }
        a{
            text-underline: none;
            color: #fff;
        }
        .content-2
        {
            line-height: 30px;
            color: #343434;
        }
        .content-2 .p
        {
            text-align: justify;
            margin-bottom: 35px;


        }
        .content-2 .prg
        {


            border-bottom: 2px solid #EAEAEA;

        }

        .content-2 .prg h2
        {
            padding-top: 5px;
            padding-bottom: 1px;
            color: #017C73;
        }


        /*bootstrap*/
        .progress
        {
            background-color: #017C73;
            margin-bottom: 20px;
            margin-top: 5px;
        }
        .progress-bar
        {
            background-color: #fff;
            color: #666666;
        }

        .content-2 .expr
        {
            display: flex;
        }
        .content-2 .expr-s
        {
            margin-left: 110px;
        }

        .content-2 .expr span
        {
            padding-right: 55px;
        }

        .content-2 .expr .p1
        {
            font-weight: bold;
        }
        .content-2 .experience
        {
            border-bottom: 2px solid #EAEAEA;
        }


    </style>


</head>
<body>
<section>
    <div>
        <div class="row">

            <div class="col-sm-4">
                <div class="pref">
                <div class="content">
                    <div class="name">
                        <h1>Reda Awad</h1>
                        <h2>Full Stack developer</h2>
                    </div>

                </div>
                <div class="info">
                    <div class="info-h">
                        <h2>Personal Info</h2>

                    </div>
                    <div class="email">
                        <h4>E-mail</h4>
                        <a href="#"><p>redaawad622@gmail.com</p></a>
                        <h4>Facebook</h4>
                        <a href="https://www.facebook.com/faris.capo.9"><p>Reda Awad</p></a>
                        <h4>LinkedIn</h4>
                        <a href="#"><p>redaawad622@gmail.com</p></a>
                        <h4>E-mail</h4>
                        <a href="#"><p>redaawad622@gmail.com</p></a>


                    </div>

                </div>

                <div class="skill">
                    <div class="skill-h">
                        <h2>Skills</h2>

                    </div>
                    <div class="skill-o">
                        <h4>PHP</h4>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" style="width: 60%;" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100">60%</div>
                        </div>
                        <h4>MySql</h4>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" style="width: 60%;" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100">60%</div>
                        </div>
                        <h4>Laravel</h4>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">50%</div>
                        </div>
                        <h4>Html</h4>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">70%</div>
                        </div>

                        <h4>Css</h4>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">70%</div>
                        </div>
                        <h4>Javascript</h4>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" style="width: 40%;" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100">40%</div>
                        </div>

                        <h4>BootStrap</h4>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">70%</div>
                        </div>


                    </div>

                </div>

                </div>

            </div>
            <div class="col-sm-8">
                <div class="content-2">
                    <div class="prg">
                        <p class="p">
                            (Example Summary) Multi-tasking Admin Assistant with +2 years of experience in the retail real-estate industry. Can manage +3 executive schedules. Looking to leverage proven communication, travel planning, and email management skill in the position of Administrative Assistant at Acme.
                        </p>
                    </div>
                    <div class="prg">
                        <h2>
                            Experience
                        </h2>
                    </div>
                    <div class="experience">
                        <div class="expr">
                        <span>
                            11-2015
                        </span>
                            <p class="p1">PHP developer</p>


                        </div>
                        <div class="expr">
                        <span>
                            11-2016
                        </span>


                            <p style="font-style: italic;">Company1</p>
                        </div>

                        <div class="expr-s">

                            <p style="font-weight: bold;">Responsibilities:</p>
                            <ul style="list-style-type: circle;">
                                <li>(Example) Trained 3 interns on customer service and office procedures</li>
                                <li>(Example) Trained 3 interns on customer service and office procedures</li>
                                <li>(Example) Trained 3 interns on customer service and office procedures</li>
                                <li>(Example) Trained 3 interns on customer service and office procedures</li>
                            </ul>

                        </div>
                    </div>


                    <div class="prg">
                        <h2>
                            Education
                        </h2>
                    </div>
                    <div class="education">
                        <div class="expr">
                        <span>
                            11-2016
                        </span>

                            <p style="font-weight: bold;">University of Mansoura at Computer & Information (IT)</p>
                        </div>
                        <div class="expr-s">


                            <ul style="list-style-type: circle;">
                                <li>(Example) Trained 3 interns on customer service and office procedures</li>
                                <li>(Example) Trained 3 interns on customer service and office procedures</li>

                            </ul>

                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>

</section>

<script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src='<?php echo e(asset('js/jquery-2.2.2.min.js')); ?>'></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>

<script src="<?php echo e(asset('js/jquery.nicescroll.min.js')); ?>"></script>

</body>
</html>