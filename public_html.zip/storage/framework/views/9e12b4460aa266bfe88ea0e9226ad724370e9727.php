<?php $__env->startSection('content'); ?>

    <div class="container">
        <!-- Add A New Medications form   -->
        <!-- Medication -->
        <div class="statistic  align-items-center bg-white has-shadow" id="med">
            <h3>Add A New Medications</h3>
            <form method="post" action="/medecin" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="formGroupExampleInput">Title</label>
                    <input class="form-control <?php if ($errors->has('MTitle')){echo 'is-invalid';} ?>" type="text" name="MTitle" placeholder="title input">
                    <div class="invalid-feedback">
                        <?php $__currentLoopData = $errors->get('MTitle'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">description</label>
                    <textarea class="form-control <?php if ($errors->has('MDesc')){echo 'is-invalid';} ?>" name="MDesc" id="exampleFormControlTextarea1" rows="3"></textarea>
                    <div class="invalid-feedback">
                        <?php $__currentLoopData = $errors->get('MDesc'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlFile1">Medication picture</label>
                    <input type="file" accept="image/*" class="form-control-file <?php if ($errors->has('MUrl')){echo 'is-invalid';} ?>" name="MUrl" id="exampleFormControlFile1" required>
                    <div class="invalid-feedback">
                        <?php $__currentLoopData = $errors->get('MUrl'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
            </form>
        </div>

        <!-- end  Medication -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>