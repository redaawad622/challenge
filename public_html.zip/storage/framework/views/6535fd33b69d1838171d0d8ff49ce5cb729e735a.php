<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=600">
      <title>Home</title>
      <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

      <link href="css/bootstrap.css" rel="stylesheet">
      <link rel="stylesheet" href="css/hover.css">
      <link href="css/home.css" rel="stylesheet">
      <link rel="stylesheet" href="css/animate.css">
      <link href="css/font-awesome.css" rel="stylesheet">
      <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
      <![endif]-->
   </head>
   <body>
      <!--start section header-->
      <section class="he">
         <!--nav2-->
         <div class="dro">
            <div class="dropdown">
               <button onclick="myFunction()" class="dropbtn">MENU</button>
               <div id="myDropdown" class="dropdown-content">

                  <li class="nav-item dropdown  hvr-shrink">
                     <a class="nav-link " data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Daily Report </a>
                     <div  class="dropdown-menu">
                        <a style="color: black !important;"  class="dropdown-item" href="/dailyReportMorning">Morning</a>
                        <a style="color: black !important;" class="dropdown-item" href="/dailyReportEvening">Evening</a>

                     </div>
                  </li>
                  <a class="nav-link hvr-shrink" href="/monthReport" target="_blank">Monthly Report  </a>
                  <a class="nav-link hvr-shrink " href="/monthPlan" target="_blank">Monthly Plan </a>
                  <a class="nav-link hvr-shrink" href="/weeklyPlan" target="_blank">Weekly Plan </a>
                  <a class="nav-link hvr-shrink" href="/vaction" target="_blank">Vacations  </a>
               </div>
            </div>
         </div>
         <i class="fa fa-bars fa-lg hvr-sink" id="bars" aria-hidden="true"></i>
         <div class="he-icon">

         </div>
         <div class="feed wow fadeInDownBig" data-wow-duration="3s" data-wow-offset="300" data-toggle="modal" data-target="#exampleModal">
            <span>feedback </span>
         </div>
         <div class="container">
            <div class="row">
               <div class="col-sm-4 col-md-3 col-lg-2">
                  <div class="he-img">
                     <img src="image/<?php echo e(Auth::user()->url); ?>" alt="personal">
                  </div>
               </div>
               <div class="col-sm-4 col-md-3 col-lg-2">
                  <div class="peso">
                     <small><?php $email=explode('@',Auth::user()->email);echo '@'.$email[0];?></small>
                     <h2>Dr/<?php echo e(Auth::user()->name); ?></h2>
                  </div>
               </div>
               <div class="na">
                  <ul>
                     <li> <a href="/"><i class="fa fa-home fa-lg"  aria-hidden="true"></i> Home</a></li>
                    <?php if(Auth::check() && Auth::user()->hasRole('user')): ?>

                        <li> <a href="/profile"><i class="fa fa-user fa-lg" aria-hidden="true"></i> profile</a></li>
                        <li><a  style="font-size: 20px;font-weight: 800;" href="/logout" class="logout">Logout<i class="fa fa-sign-out"></i></a></li>


                     <?php else: ?>

                        <li> <a href="/admin"><i class="fa fa-user fa-lg" aria-hidden="true"></i> Admin</a></li>
                       <li><a  style="font-size: 20px;font-weight: 800;" href="/logout" class="nav-link logout">Logout<i class="fa fa-sign-out"></i></a></li>


                     <?php endif; ?>


                  </ul>
               </div>
            </div>
         </div>
      </section>
      <!--end section header-->
      <!--start section body-->
      <section class="bod">
         <div class="container">
            <div class="row">
               <div class="col-sm-0 col-md-2">
               </div>
               <div class="col-sm-12 col-md-10">
                  <div class="posts">
                     <?php if(Auth::check()&&Auth::user()->hasRole('admin')): ?>
                     <form action="/post" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                     <div class="inst">
                        <img src="image/<?php echo e(Auth::user()->url); ?>" alt="personal">

                        <input type="text" name="instruction" style="color:black" class="form-control hvr-rectangle-out" placeholder="What Are The Instruction......?">
                        <input type="file" id="file" name="file" class="up" style="display: none">

                        <input type="file" name="url"  accept="image/*" class="up2" style="display: none">
                        <input type="text" name="file_name" style="display: none;" value="" id="select_file">
                        <div class="bod-icon ">
                         <i class="fa fa-folder-open fa-2x hvr-grow " id="i" aria-hidden="true"> </i>
                           <i class="fa fa-camera fa-2x hvr-grow i2 " id="ic" aria-hidden="true"></i>
                           <i class="fa fa-ellipsis-h fa-2x hvr-grow " id="ic" aria-hidden="true"></i>
                           <input type="submit" value="Post" id="sub"  class="btn btn-primary  hvr-round-corners">
                        </div>

                     </div>
                     </form>
                     <?php endif; ?>
                        <?php if($errors->any()): ?>
                           <div class="alert alert-danger">
                              <ul>
                                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                           </div>
                        <?php endif; ?>

                     <!--Start nav-->
                     <ul class="nav">

                        <li class="nav-item dropdown  hvr-shrink">
                           <a class="nav-link " data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Daily Report <i class="fa fa-caret-down  fa-lg" id="ic" aria-hidden="true"></i></a>
                           <div  class="dropdown-menu">
                              <a style="color: black !important;"  class="dropdown-item" href="/dailyReportMorning">Morning</a>
                              <a style="color: black !important;" class="dropdown-item" href="/dailyReportEvening">Evening</a>

                           </div>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link hvr-shrink" href="/monthReport" target="_blank">Monthly Report</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link hvr-shrink " href="/monthPlan" target="_blank">Monthly Plan </a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link hvr-shrink" href="/weeklyPlan" target="_blank">Weekly plan </a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link hvr-shrink " href="/vaction" target="_blank">Vactions  <i class="fa fa-caret-down  fa-lg" id="ic" aria-hidden="true"></i></a>
                        </li>
                     </ul>
                     <!-- end nav-->
                     <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay=> $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="rpost" id="p<?php echo e($kay); ?>">

                        <div class="dropdown show " style="float: right">

                              <i role="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="fa fa-caret-down  fa-lg ic<?php echo e($kay); ?>" id="ic" aria-hidden="true"></i>

                           <div class="dropdown-menu dropdown-menu-right dropd<?php echo e($kay); ?>" STYLE="display: none" aria-labelledby="ic">
                              <a class="dropdown-item hide<?php echo e($kay); ?>"  >Hide</a>
                              <?php if(Auth::check()&&Auth::user()->hasRole('admin')): ?>
                              <a class="dropdown-item" href="/removepost/<?php echo e($post->id); ?>">Remove</a>
                              <?php endif; ?>

                           </div>
                        </div>
                        <img src="image/<?php echo e(Auth::user()->url); ?>" class="img" alt="personal">
                        <h2>Dr/Eslam <small><?php echo date('d.M.Y',strtotime($post->created_at));?></small>  </h2>
                        <small class="h"><?php
                            $now = time(); // or your date as well
                            $your_date = strtotime($post->created_at);
                            $datediff = $now - $your_date;

                            if(floor($datediff/60/60 )<24)
                                {

                            echo floor($datediff/60/60 ).' H '.floor(($datediff/60)-(floor($datediff/60/60 )*60)).' min'  ;
                            }
                        ?></small>
                        <?php if(isset($post->instruction)): ?>
                        <p id="re2<?php echo e($kay); ?>"><?php
                                $po=ucwords($post->instruction);
                            $words = explode(' ',$po);
                            $words2 = explode(' ',$po);
                            echo implode(' ', array_slice($words, 0, 30));
                            if(count($words2)>30)
                                {

                                    echo '<span id="read" '.'class="readMore'.$kay.'"' .'>'. " Read More.........".'</span>' ;

                                }

                            ?></p>
                        <p id="re<?php echo e($kay); ?>" style="display: none;"><?php echo e(ucwords($post->instruction)); ?> <span id="read" class="readLess<?php echo e($kay); ?>"> Read Less</span></p>
                        <?php endif; ?>

                        <?php if(isset($post->file)): ?>
                           <div class="file">
                                 <i class="fa <?php $extin=explode('.',$post->file);echo $extin[1];
                                 if($extin[1]=='pdf' ||$extin[1]=='PDF'){echo' fa-file-pdf-o';}
                                 elseif ($extin[1]=='doc' ||$extin[1]=='DOC'||$extin[1]=='DOCX'||$extin[1]=='docx'){echo' fa-file-word-o';}
                                 elseif ($extin[1]=='xls' ||$extin[1]=='XLS'||$extin[1]=='XLSX'||$extin[1]=='xlsx'){echo' fa-file-excel-o';}
                                 elseif ($extin[1]=='ppt' ||$extin[1]=='PPT'){echo' fa-file-powerpoint-o';}
                                 else {echo ' fa-file-text-o';}
                                 ?>" style="
                                           float: none;
                                           font-size: 80px;
                                           margin-bottom: 20px;
                                           position: relative;
                                           bottom: inherit;
                                           padding-top: 36px;
                                  "></i>
                           <h4><?php echo e($post->real_name); ?></h4><br>
                           <small style="position: relative;right: 110%;color: #90949c"><?php $extin=explode('.',$post->file);echo $extin[1];?></small><br>

                           <a style="position: relative;right: 110%;" href="image/<?php echo e($post->file); ?>"><button class="btn-primary" style="background: #6495d7; ">Download</button></a>

                        </div>
                        <?php endif; ?>
                        <?php if(isset($post->url)): ?>

                        <div class="text-center">
                           <img src="image/<?php echo e($post->url); ?>" class="img-fluid rounded post-img" alt="post-img">
                        </div>
                        <?php endif; ?>

                        <hr class="hr">
                        <div class="logo">

                           <img src="image/rsz_preview.jpg" style="height: 30px; width: 30px;" alt="logo">
                        </div>
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>
               </div>
            </div>
         </div>
         <!-- model feedback-->
         <!-- model feedback-->
         <form action='/sandmail' method='post' enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
               <div class="modal-dialog" role="document">
                  <div class="modal-content"> <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">New Feedback</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <div class="modal-body">

                        <div class="form-group">
                           <input class="form-control  <?php if ($errors->has('name')) {echo 'is-invalid';} ?>" name="name" type="text" placeholder="Name" required>
                           <div class="invalid-feedback">
                              <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($message); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                        <div class="form-group">
                           <input class="form-control  <?php if ($errors->has('subject')) {echo 'is-invalid';} ?>" name="subject" type="text" placeholder="subjct" required> </div> <div class="form-group">
                           <div class="invalid-feedback">
                              <?php $__currentLoopData = $errors->get('subject'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($message); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                           <br>

                           <textarea class="form-control <?php if ($errors->has('body')) {echo 'is-invalid';} ?>" name="body" id="exampleFormControlTextarea1" rows="3" required></textarea>
                           <div class="invalid-feedback">
                              <?php $__currentLoopData = $errors->get('body'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($message); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                           <div class="invalid-feedback">
                              <?php $__currentLoopData = $errors->get('url'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($message); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                           <div class="invalid-feedback">
                              <?php $__currentLoopData = $errors->get('file'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($message); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                        <input type="file" class="up3" name="url" accept="image/*" style="display: none" >
                        <input type="file" name="file" class="up4" style="display: none" >

                     </div>
                     <div class="modal-footer">
                        <div class="send-icon">
                           <div class="fa fa-folder-open fa-2x i4" id="i" aria-hidden="true"></div>
                           <div class="fa fa-camera fa-2x i3" id="ic" aria-hidden="true">


                           </div>
                        </div>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Send message</button>
                     </div>
                  </div>
               </div>
            </div>
         </form>

      </section>
      <!--section loading-->
      <section class="overlay">
         <div class="sk-cube-grid">
            <div class="sk-cube sk-cube1"></div>
            <div class="sk-cube sk-cube2"></div>
            <div class="sk-cube sk-cube3"></div>
            <div class="sk-cube sk-cube4"></div>
            <div class="sk-cube sk-cube5"></div>
            <div class="sk-cube sk-cube6"></div>
            <div class="sk-cube sk-cube7"></div>
            <div class="sk-cube sk-cube8"></div>
            <div class="sk-cube sk-cube9"></div>
         </div>
      </section>
      <script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="<?php echo e(asset('js/popper.min.js')); ?>" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
      <script src='<?php echo e(asset('js/jquery-2.2.2.min.js')); ?>'></script>
      <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
      <script src="js/wow.min.js"></script>
      <script>
         new WOW().init();
      </script>
      <script src="js/jquery.nicescroll.min.js"></script>
      <script src="js/myjs.js" type="text/javascript"></script>
   <script type="text/javascript">


       $('.i3').click(function () {
           $('.up3').click();
       })
       $('.i4').click(function () {
           $('.up4').click();
       });

       $('#i').click(function () {
          $('.up').click();
       })
       $('.i2').click(function () {
           $('.up2').click();
       });


       <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay=> $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       $('.readMore<?php echo e($kay); ?>').click(function () {
           $('#re<?php echo e($kay); ?>').show();
           $('#re2<?php echo e($kay); ?>').hide();
       });
       $('.readLess<?php echo e($kay); ?>').click(function () {
           $('#re<?php echo e($kay); ?>').hide();
           $('#re2<?php echo e($kay); ?>').show();
       });

       $('.ic<?php echo e($kay); ?>').click(function () {
           $('.dropd<?php echo e($kay); ?>').fadeToggle();
       });
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       $('#file').change(function () {
          var fi=$('#file').val();
          $('#select_file').attr('value',fi);
       });
       <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay=> $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       $('.hide<?php echo e($kay); ?>').click(function () {

          $('#p<?php echo e($kay); ?>').hide();
       });

       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



   </script>
   </body>
</html>