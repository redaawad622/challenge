<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Profile</title>
      <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet">
      <link href="css/bootstrap.css" rel="stylesheet">
      <link href="css/profile.css" rel="stylesheet">
      <link rel="stylesheet" href="css/hover.css">
      <link rel="stylesheet" href="css/animate.css">
      <link href="css/font-awesome.css" rel="stylesheet">
      <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
      <![endif]-->
   </head>
   <body>
      <!--start section header-->
      <section class="he">
         <!--nav2-->
         <div class="dro">
            <div class="dropdown">
               <button onclick="myFunction()" class="dropbtn">MENU</button>
               <div id="myDropdown" class="dropdown-content">
                  <a class="nav-link hvr-shrink" href="Forms/dailyReport.htm" target="_blank">Daily Report<span class="sr-only">(current)</span></a>
                  <a class="nav-link hvr-shrink" href="Forms/monthReport.htm" target="_blank">Month Report  </a>
                  <a class="nav-link hvr-shrink " href="Forms/daliyWorkProg.htm" target="_blank">Daily Work Program </a>
                  <a class="nav-link hvr-shrink" href="#" target="_blank">Weekly Work Program </a>
                  <a class="nav-link hvr-shrink" href="Forms/vaction.htm" target="_blank"> Vactions  </a>
               </div>
            </div>
         </div>
         <div class="he-icon">
            <i class="fa fa-search fa-lg" aria-hidden="true"></i>&nbsp;&nbsp;
            <a href="/home"><i class="fa fa-home fa-lg" aria-hidden="true"></i></a>&nbsp;&nbsp;
            <i class="fa fa-ellipsis-v fa-lg" aria-hidden="true"></i>
         </div>
         <div class="feed  wow fadeInDownBig" data-wow-duration="3s" data-wow-offset="300" data-toggle="modal" data-target="#exampleModal">
            <span>feedback </span>
         </div>
         <div class="container">
            <div class="row">
               <div class="as">
                  <div class="col-xs-12">
                     <div class="he-img">
                        <img src="image/personal.png" alt="personal">
                     </div>
                     <div class="peso">
                        <small>@me_ahmed</small>
                        <h2>Dr/Ahmed</h2>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--end section header-->
      <!--start section body-->
      <section class="bod">
         <div class="container">
            <div class="row">
               <div class="col-sm-0 col-md-1 ">
               </div>
               <div class="col-sm-12 col-md-10">
                  <div class="posts">
                     <!--Start nav-->
                     <ul class="nav">
                        <li class="nav-item ">
                           <a class="nav-link hvr-shrink" href="Forms/dailyReport.htm" target="_blank">Daily Report <i class="fa fa-caret-down fa-lg" id="ic" aria-hidden="true"></i><span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link hvr-shrink" href="Forms/monthReport.htm" target="_blank">Month Report  <i class="fa fa-caret-down  fa-lg" id="ic" aria-hidden="true"></i></a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link hvr-shrink " href="Forms/vaction.htm" target="_blank"> Vactions <i class="fa fa-caret-down fa-lg" id="ic" aria-hidden="true"></i></a>
                        </li>
                        <li class="nav-item" id="active">
                           <a class="nav-link hvr-shrink " href="#" target="_blank"> <i class="fa fa-bars fa-lg" id="ic" aria-hidden="true"></i> Activity</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link hvr-shrink" href="#" target="_blank">Weekly Work Program  <i class="fa fa-caret-down  fa-lg" id="ic" aria-hidden="true"></i></a>
                        </li>
                        <li class="nav-item" target="_blank">
                           <a class="nav-link hvr-shrink" href="Forms/daliyWorkProg.htm">  Daily Work Program <i class="fa fa-caret-down  fa-lg" id="ic" aria-hidden="true"></i></a>
                        </li>
                     </ul>
                     <!-- end nav-->
                     <div class="rpost">
                        <i class="fa fa-caret-down  fa-lg" id="ic" aria-hidden="true"></i>
                        <img src="image/personal.png" alt="personal">
                        <h2>Dr/Mohamed <small>22.jan.2017</small>  </h2>
                        <small class="h">11hr</small>
                        <p>When I Falt The Rotation Of The Earth Everything Stoped The Silence Died</p>
                        <hr class="hr">
                        <div class="logo">
                           <span>LOGO</span>
                        </div>
                     </div>
                     <div class="rpost">
                        <i class="fa fa-caret-down  fa-lg" id="ic" aria-hidden="true"></i>
                        <img src="image/personal.png" alt="personal">
                        <h2>Dr/Mohamed <small>22.jan.2017</small>  </h2>
                        <small class="h">11hr</small>
                        <p>When I Falt The Rotation Of The Earth Everything Stoped The Silence Died</p>
                        <hr class="hr">
                        <div class="logo">
                           <span>LOGO</span>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-sm-0 col-md-1 ">
               </div>
            </div>
         </div>
         <!-- model feedback-->
         <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
               <div class="modal-content">
                  <div class="modal-header">
                     <h5 class="modal-title" id="exampleModalLabel">New Feedback</h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                     </button>
                  </div>
                  <div class="modal-body">
                     <form>
                        <div class="form-group">
                           <input class="form-control" type="text" placeholder="Name">
                        </div>
                        <div class="form-group">
                           <input class="form-control" type="text" placeholder="subjct">
                        </div>
                        <div class="form-group">
                           <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div>
                     </form>
                  </div>
                  <div class="modal-footer">
                     <div class="send-icon">
                        <i class="fa fa-folder-open fa-2x" id="i" aria-hidden="true"></i>
                        <i class="fa fa-camera fa-2x" id="ic" aria-hidden="true"></i>
                     </div>
                     <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                     <button type="button" class="btn btn-primary">Send message</button>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--section loading-->
      <section class="overlay">
         <div class="sk-cube-grid">
            <div class="sk-cube sk-cube1"></div>
            <div class="sk-cube sk-cube2"></div>
            <div class="sk-cube sk-cube3"></div>
            <div class="sk-cube sk-cube4"></div>
            <div class="sk-cube sk-cube5"></div>
            <div class="sk-cube sk-cube6"></div>
            <div class="sk-cube sk-cube7"></div>
            <div class="sk-cube sk-cube8"></div>
            <div class="sk-cube sk-cube9"></div>
         </div>
      </section>
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
      <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
      <script src="js/wow.min.js"></script>
      <script>
         new WOW().init();
      </script>
      <script src="js/jquery.nicescroll.min.js"></script>
      <script src="js/myjs.js" type="text/javascript"></script>
   </body>
</html>