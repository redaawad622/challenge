<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success" role="alert">
                <strong><?php echo e(Session::get('type')); ?> </strong> <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="statistic  align-items-center bg-white has-shadow" id="med">
            <h3 style="margin: 9px 0 31px 0px;">Control Database Table</h3>

            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-search"></i></div>
                    <input type="text" class="form-control" id="search" placeholder="Search By Table Name">
                </div>
            </div>

        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Table Name</th>
                <th>Truncate</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($table); ?></td>
                <td>
                    <form action="/admin/Truncate" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" value="<?php echo e($table); ?>" name="table_name">
                        <input type="submit" value="Truncate" class="btn btn-warning">

                    </form>
                </td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>