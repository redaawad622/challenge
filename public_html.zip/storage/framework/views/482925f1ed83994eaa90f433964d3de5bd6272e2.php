<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Promotion Plan</title>
    <link href="https://fonts.googleapis.com/css?family=Mirza" rel="stylesheet">

    <link href="../css/bootstrap.css" rel="stylesheet">

    <link href="../css/forms.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/form/blackStyle-them.css">
    <link href="../css/font-awesome.css" rel="stylesheet">

    <!--[if lt IE 9]>
          <script src="js/html5shiv.min.js"></script>
          <script src="js/respond.min.js"></script>
        <![endif]-->
</head>

<body>

    <!--section setting option-->
    <section class="option-box">
        <div class="color-option">
            <h4>Color option</h4>
            <ul class="list-unstyled">
                <li style="background:#000" data-value="../css/form/blackStyle-them.css"></li>
                <li data-value="../css/form/pinkStyle-them.css"></li>
                <li data-value="../css/form/blueStyle-them.css"></li>
                <li data-value="../css/form/seaStyle-them.css"></li>
                <li data-value="../css/form/greenStyle-them.css"></li>
                <li data-value="../css/form/violetStyle-them.css"></li>
            </ul>

        </div>
        <i class="fa fa-gear fa-3x gear-ch"></i>
    </section>

    <section class="bod">
        <form action="promotionPlan" method="post">
        <?php echo e(csrf_field()); ?>

            <div class="container-fluid">

                <hr>

                <div class="row">

                    <div class="col-md-6">

                        <div class="row">
                            <div class="col-md-3">
                                <p class="center bold padding"> اجمالي الاطباء المستهدفة ونسبتهم </p>
                                <input type="text" name="ratio" class="form-control ">
                            </div>

                            <div class="col-md-2">
                                <p class="center bold padding-lg"> التخصصات </p>
                                <div class="form-group">
                                    <p class="center bold padding-md"> عدد </p>
                                </div>                              
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> اسنان </p>
                                <div class="form-group">
                                    <input type="text" name="dentistry" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold"> علاج طبيعي </p>
                                <div class="form-group">
                                    <input type="text" name="physiotherapist" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> نفسية </p>
                                <div class="form-group">
                                    <input type="text" name="psychological" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> مسالك </p>
                                <div class="form-group">
                                    <input type="text" name="pathways" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold"> جلدية وتناسلية </p>
                                <div class="form-group">
                                    <input type="text" name="leatherGenital" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> أ.أ.ح </p>
                                <div class="form-group">
                                    <input type="text" name="a_a_h" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> عظام </p>
                                <div class="form-group">
                                    <input type="text" name="bones" class="form-control ">
                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="col-md-6">

                        <div class="row">
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> جراحة </p>
                                <div class="form-group">
                                    <input type="text" name="surgery" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> أطفال </p>
                                <div class="form-group">
                                    <input type="text" name="children" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> نساء </p>

                                <div class="form-group">
                                    <input type="text" name="women" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> حميات </p>
                                <div class="form-group">
                                    <input type="text" name="fever" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> صدر </p>
                                <div class="form-group">
                                    <input type="text" name="released" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> الباطنة </p>
                                <div class="form-group">
                                    <input type="text" name="inside" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <p class="center bold padding-lg   color"> ممارس </p>
                                <div class="form-group">
                                    <input type="text" name="Practitioner" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <p class="center bold padding-lg   color"> Groups </p>
                                <div class="form-group">
                                    <input type="text" name="groups" class="form-control ">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <p class="center bold"> specialist
                                    <br> NO.OF DOCTOR </p>

                                <div class="form-group">
                                    <input type="text" name="n_o_doctor" class="form-control ">
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

                <hr>
                <div class="row">
                    <div class="col-md-4">
                        <h5 class="center padding-t padding">مدير دعاية الفريق</h5>
                    </div>
                    <div class="col-md-4">
                        <h5 class="center padding-t padding">  مدير فرع المنصورة</h5>
                    </div>
                </div>

            </div>
            <input type="submit"  class="btn btn-primary mr-3" value="ارسال">
        </form>
    </section>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>

    <script src="../js/jquery.nicescroll.min.js"></script>
    <script src="../js/myjs.js" type="text/javascript">
    </script>
</body>

</html>