<?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="statistic  align-items-center bg-white has-shadow" id="event">
                <h3>Add A New event</h3>
                <form method="post" action="/event" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="formGroupExampleInput">Title</label>
                        <input class="form-control <?php if ($errors->has('title')){echo 'is-invalid';} ?>" type="text" name="title" value="<?php echo e(old('title')); ?>" placeholder="title input">
                        <div class="invalid-feedback">
                            <?php $__currentLoopData = $errors->get('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput">Date</label>
                        <input class="form-control <?php if ($errors->has('edate')){echo 'is-invalid';} ?>" name="edate" value="<?php echo e(old('edate')); ?>" type="date">
                        <div class="invalid-feedback">
                            <?php $__currentLoopData = $errors->get('edate'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput">Time</label>
                        <input class="form-control <?php if ($errors->has('time')){echo 'is-invalid';} ?>" type="time" name="time"value="<?php echo e(old('time')); ?>" placeholder="title input">
                        <div class="invalid-feedback">
                            <?php $__currentLoopData = $errors->get('time'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">description</label>
                        <textarea class="form-control <?php if ($errors->has('desc')){echo 'is-invalid';} ?>" name="desc" value="<?php echo e(old('desc')); ?>" id="exampleFormControlTextarea1" rows="3"></textarea>
                        <div class="invalid-feedback">
                            <?php $__currentLoopData = $errors->get('desc'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlFile1">Event picture</label>
                        <input type="file" accept="image/*" class="form-control-file <?php if ($errors->has('url')){echo 'is-invalid';} ?>" name="url" id="exampleFormControlFile1" required>
                        <div class="invalid-feedback">
                            <?php $__currentLoopData = $errors->get('url'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <button type="submit" id="spt" class="btn btn-primary">Add</button>
                </form>
            </div>


            </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>