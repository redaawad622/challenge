<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=1024">


    <title>daliy Report</title>
    <link href="https://fonts.googleapis.com/css?family=Mirza" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/forms.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/form/blackStyle-them.css">
    <link href="../css/font-awesome.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<section class="option-box">
    <div class="color-option">
        <h4>Color option</h4>
        <ul class="list-unstyled">
            <li style="background:#000" data-value="../css/form/blackStyle-them.css"></li>
            <li data-value="../css/form/pinkStyle-them.css"></li>
            <li data-value="../css/form/blueStyle-them.css"></li>
            <li data-value="../css/form/seaStyle-them.css"></li>
            <li data-value="../css/form/greenStyle-them.css"></li>
            <li data-value="../css/form/violetStyle-them.css"></li>
        </ul>
    </div>
    <i class="fa fa-gear fa-3x gear-ch"></i>
</section>
<section class="bod container">
    <h3> <span class="padding-r-xl"> الشركة المصرية الدولية للصناعات الدوائية - ايبيكو</span> <span class="left" >القطاع التجاري-فرع المنصورة<br><br><img class="padding-r-lg" src="../image/LogoImageMasterPage.jpg"> </span></h3>
    <h3>   السيد الدكتور/ مدير دعاية الفريق الأول</h3>
    <br>
    <h3 class="center padding-r-xl"> تحية طيبة وبعد.......,</h3>
    <br>
    <form action="/dailyReportEvening" method="post">
        <?php echo e(csrf_field()); ?>

        <table class="table">

            <tbody>
            <tr>

                <td colspan="2"><div class="form-inline right">
                        <div class="form-group">
                            <label class="bold p" for="inputPassword6">  <h3>  مقدمه لسيادتكم دكتور/ </h3></label>

                            <input type="text"  class="form-control mx-sm-3" >
                        </div>
                    </div></td>
                <td colspan="2"> </td>



            </tr>
            <tr>

                <td colspan="2"><div class="form-inline right">
                        <div class="form-group">
                            <label class="bold p" for="inputPassword6">تقرير عمل عن  يوم </label>
                            <input type="text" id="inputPassword6" class="form-control mx-sm-3" value="<?php echo date('l',time())?>">
                        </div>
                    </div></td>
                <td colspan="2"> <div class="form-inline left">
                        <div class="form-group">
                            <label class="bold p" for="inputPassword6">الموافق</label>
                            <input type="text"  name="date" id="inputPassword6" value="<?php echo date('Y-m-d',time())?>" class="form-control mx-sm-3">
                        </div>
                    </div>
                </td>

            </tr>
            <tr>

                <td>  <h4 class="m-t-sm">-:المسائي</h4></td>
                <td colspan="2"> <div class="form-inline left">
                        <div class="form-group">
                            <label class="bold p" for="inputPassword6">مع دكتور </label>

                            <input type="text" id="inputPassword6" name="withDoctor" class="form-control mx-sm-3  <?php if ($errors->has('withDoctor')) {echo 'is-invalid';} ?>">

                          <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('withDoctor'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <input type="text" name="km" id="inputPassword6" class="form-control   <?php if ($errors->has('km')) {echo 'is-invalid';} ?>" placeholder="كم">

                      <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('km'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </div>

                </td>
            </tr>
            <tr>

                <td> <h4 class="center">  اسم الطبيب</h4></td>
                <td>   <h4 class="center">التخصص </h4></td>
                <td> <h4 class="center">  الكود </h4></td>
                <td> <h4 class="center">  ملاحظات </h4></td>
            </tr>
            <tr>
                <td>
                    <div class="form-group">
                        <input type="text" name="doctorName" class="form-control  <?php if ($errors->has('doctorName')) {echo 'is-invalid';} ?>" required>

                      <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('doctorName'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <input type="text" name="special"  class="form-control  <?php if ($errors->has('special')) {echo 'is-invalid';} ?>" required>

                      <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('special'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <input type="text" name="kode" class="form-control  <?php if ($errors->has('kode')) {echo ' is-invalid';} ?>">

                      <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('kode'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <input type="text" name="note" class="form-control  <?php if ($errors->has('note')) {echo 'is-invalid';} ?>" >

                      <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('note'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="4"> <h4 > -:ملاحظات عامة</h4></td>
            </tr>
            <tr>
                <td colspan="4">
                    <div class="form-group">
                        <textarea class="form-control  <?php if ($errors->has('publicNote')) {echo 'is-invalid';} ?>"  name="publicNote" id="exampleFormControlTextarea1" rows="3"></textarea>

                      <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('publicNote'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <h3 class="padding-md">مقدم لسيادتكم </h3>


                </td>
                <td colspan="2">

                    <h3 class="left" >مدير دعاية الفريق الأول</h3>

                </td>
            </tr>
            <tr>
                <td colspan="4">
                    <input type="submit" class="btn btn-primary mr-3" value="ارسال">

                </td>
            </tr>

            </tbody>
        </table>

    </form>


    <?php if(!$errors->any()): ?>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success" role="alert">
            <strong><?php echo e(Session::get('type')); ?> </strong> <?php echo e(Session::get('message')); ?>

        </div>
         <?php endif; ?>
    <?php else: ?>
        <div class="alert alert-danger" role="alert">
            <strong> Warning! </strong> please Check the error and  try submitting again.
        </div>
    <?php endif; ?>



</section>
<script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src='<?php echo e(asset('js/jquery-2.2.2.min.js')); ?>'></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
<script src="../js/jquery.nicescroll.min.js"></script>
<script  src="../js/myjs.js" type="text/javascript">  </script>

</body>
</html>