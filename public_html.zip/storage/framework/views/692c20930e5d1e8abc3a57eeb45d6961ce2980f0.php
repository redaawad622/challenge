<?php $__env->startSection('content'); ?>
         <div class="page-content d-flex align-items-stretch">
            <!-- Side Navbar -->
            <nav class="side-navbar">
               <!-- Sidebar Header-->
               <div class="sidebar-header d-flex align-items-center">
                  <div class="avatar"><img src="image/avatar-1.jpg" width="55px" height="55px" alt="..." class="image-fluid rounded-circle"></div>
                  <div class="title">
                     <h1 class="h4">Dr/eslam</h1>
                     <p>The Admin</p>
                  </div>
               </div>
               <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
               <ul class="list-unstyled">
                  <li class="active"> <a href="/"><i class="icon-home"></i>Home</a></li>
                  <li>
                     <a href="#dashvariants" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Managment Tamplet </a>
                     <ul id="dashvariants" class="collapse list-unstyled">
                        <li><a href="Forms/checks.htm" target="_blank">Delegate receipt of checks</a></li>
                        <li><a href="Forms/letter.htm" target="_blank">Letter of guarantee</a></li>
                        <li><a href="Forms/priceShow.htm" target="_blank">Show Prices</a></li>
                     </ul>
                  </li>
               </ul>
               <span class="heading"> <i class="fa fa-users" aria-hidden="true"></i> Users</span>
               <ul class="list-unstyled">
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="wow fadeInLeftBig" data-wow-duration="2s" data-wow-delay=".5s" data-wow-offset="300">
                     <img src="image/<?php echo e($user->url); ?>" alt="..." height="30px" width="30px" class="image-fluid rounded-circle">&nbsp; Dr/<?php echo e($user->name); ?> &nbsp; &nbsp; &nbsp;<a href="/deletuser/<?php echo e($user->id); ?>"> <i class="fa fa-trash-o" aria-hidden="true"></i> </a>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </ul>
            </nav>
            <div class="content-inner">
               <!-- Page Header-->
               <header class="page-header">
                  <div class="container-fluid">
                     <h2 class="no-margin-bottom">Dashboard</h2>
                  </div>
               </header>
               <!-- Dashboard Counts Section-->
               <section class="dashboard-counts no-padding-bottom">
                  <div class="container-fluid">
                     <div class="row bg-white has-shadow">
                        <!-- Item -->
                        <div class="col-xl-3 col-sm-6">
                           <div class="item d-flex align-items-center">
                              <div class="icon bg-violet"><i class="icon-user"></i></div>
                              <div class="title">
                                 <span>Daily<br>Reports</span>
                                 <div class="progress">
                                    <div role="progressbar" style="width: 25%; height: 4px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-violet"></div>
                                 </div>
                              </div>
                              <div class="number"><strong>25</strong></div>
                           </div>
                        </div>
                        <!-- Item -->
                        <div class="col-xl-3 col-sm-6">
                           <div class="item d-flex align-items-center">
                              <div class="icon bg-red"><i class="icon-padnote"></i></div>
                              <div class="title">
                                 <span>month<br>Reports</span>
                                 <div class="progress">
                                    <div role="progressbar" style="width: 25%; height: 4px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-red"></div>
                                 </div>
                              </div>
                              <div class="number"><strong>70</strong></div>
                           </div>
                        </div>
                        <!-- Item -->
                        <div class="col-xl-3 col-sm-6">
                           <div class="item d-flex align-items-center">
                              <div class="icon bg-green"><i class="icon-bill"></i></div>
                              <div class="title">
                                 <span>weekly<br>Programing</span>
                                 <div class="progress">
                                    <div role="progressbar" style="width: 25%; height: 4px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-green"></div>
                                 </div>
                              </div>
                              <div class="number"><strong>44</strong></div>
                           </div>
                        </div>
                        <!-- Item -->
                        <div class="col-xl-3 col-sm-6">
                           <div class="item d-flex align-items-center">
                              <div class="icon bg-orange"><i class="icon-check"></i></div>
                              <div class="title">
                                 <span>dialy<br>Programing</span>
                                 <div class="progress">
                                    <div role="progressbar" style="width: 25%; height: 4px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-orange"></div>
                                 </div>
                              </div>
                              <div class="number"><strong>35</strong></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="dashboard-counts no-padding-bottom">
                  <div class="container-fluid">
                     <div class="row bg-white has-shadow">
                        <!-- Item -->
                        <div class="col-xl-4 col-sm-6">
                           <div class="item d-flex align-items-center">
                              <div class="icon bg-violet"><i class="icon-user"></i></div>
                              <div class="title">
                                 <a class="list-c" href="Forms/promotionPlan.htm" target="_blank"><span>promotion<br>plan</span></a>
                                 <div class="progress">
                                    <div role="progressbar" style="width: 25%; height: 4px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-violet"></div>
                                 </div>
                              </div>
                              <div class="number"><strong>25</strong></div>
                           </div>
                        </div>
                        <!-- Item -->
                        <div class="col-xl-4 col-sm-6">
                           <div class="item d-flex align-items-center">
                              <div class="icon bg-red"><i class="icon-padnote"></i></div>
                              <div class="title">
                                 <span>Comparison of the sale<br> by sector</span>
                                 <div class="progress">
                                    <div role="progressbar" style="width: 25%; height: 4px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-red"></div>
                                 </div>
                              </div>
                              <div class="number"><strong>70</strong></div>
                           </div>
                        </div>
                        <!-- Item -->
                        <div class="col-xl-4 col-sm-6">
                           <div class="item d-flex align-items-center">
                              <div class="icon bg-green"><i class="icon-bill"></i></div>
                              <div class="title">
                                 <span>Annual morning<br> assessment</span>
                                 <div class="progress">
                                    <div role="progressbar" style="width: 25%; height: 4px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-green"></div>
                                 </div>
                              </div>
                              <div class="number"><strong>44</strong></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <!-- Dashboard Header Section    -->
               <section class="dashboard-header">
                  <div class="container-fluid">
                     <div class="row">
                        <!-- Medication -->
                        <div class="statistics col-lg-6 col-12">
                           <div class="statistic  align-items-center bg-white has-shadow">
                              <h3>Add A New Medications</h3>
                              <form method="post" action="/medecin" enctype="multipart/form-data">
                                 <?php echo e(csrf_field()); ?>

                                 <div class="form-group">
                                    <label for="formGroupExampleInput">Title</label>
                                    <input class="form-control" type="text" name="MTitle" placeholder="title input">
                                 </div>
                                 <div class="form-group">
                                    <label for="exampleFormControlTextarea1">description</label>
                                    <textarea class="form-control" name="MDesc" id="exampleFormControlTextarea1" rows="3"></textarea>
                                 </div>
                                 <div class="form-group">
                                    <label for="exampleFormControlFile1">Medication picture</label>
                                    <input type="file" class="form-control-file" name="MUrl" id="exampleFormControlFile1">
                                 </div>
                                 <button type="submit" class="btn btn-primary">Add</button>
                              </form>
                           </div>
                           <div class="statistic  align-items-center bg-white has-shadow">
                              <h3>Add Gallery Picture</h3>
                              <form method="post" action="/img" enctype="multipart/form-data">
                                 <?php echo e(csrf_field()); ?>

                                 <div class="form-group">
                                    <label for="exampleFormControlFile1">choose picture</label>
                                    <input type="file" class="form-control-file" name="MUrl" id="exampleFormControlFile1">
                                 </div>
                                 <button type="submit" class="btn btn-primary">Add</button>
                              </form>
                           </div>
                           <!--objective-->
                           <div class="statistic  align-items-center bg-white has-shadow">
                              <h3>Edit Objective</h3>
                              <form method="post" action="/objective">
                                 <?php echo e(csrf_field()); ?>

                                 <div class="form-group">
                                    <label for="exampleFormControlTextarea1">Objective</label>
                                    <textarea class="form-control" name="body" id="exampleFormControlTextarea1" rows="3"></textarea>
                                 </div>
                                 <button type="submit" class="btn btn-primary">Add</button>
                              </form>
                           </div>
                        </div>
                        <!--event-->
                        <div class="statistics col-lg-6 col-12">
                           <div class="statistic  align-items-center bg-white has-shadow">
                              <h3>Add A New event</h3>
                              <form method="post" action="/event" enctype="multipart/form-data">
                                 <?php echo e(csrf_field()); ?>

                                 <div class="form-group">
                                    <label for="formGroupExampleInput">Title</label>
                                    <input class="form-control" type="text" name="title" placeholder="title input">
                                 </div>
                                 <div class="form-group">
                                    <label for="formGroupExampleInput">Date</label>
                                    <input class="form-control" name="date" type="date">
                                 </div>
                                 <div class="form-group">
                                    <label for="formGroupExampleInput">Time</label>
                                    <input class="form-control" type="time" name="time" placeholder="title input">
                                 </div>
                                 <div class="form-group">
                                    <label for="exampleFormControlTextarea1">description</label>
                                    <textarea class="form-control" name="desc" id="exampleFormControlTextarea1" rows="3"></textarea>
                                 </div>
                                 <div class="form-group">
                                    <label for="exampleFormControlFile1">Medication picture</label>
                                    <input type="file" class="form-control-file" name="url" id="exampleFormControlFile1">
                                 </div>
                                 <button type="submit" id="spt" class="btn btn-primary">Add</button>
                              </form>
                           </div>
                           <div class="statistic  align-items-center bg-white has-shadow">
                              <h3>private instruction</h3>
                              <form method="post" action="/inst">
                                 <?php echo e(csrf_field()); ?>

                                 <div class="form-group">
                                    <label for="exampleFormControlTextarea1">Message content</label>
                                    <textarea class="form-control" name="body" id="exampleFormControlTextarea1" rows="3"></textarea>
                                 </div>
                                 <label class="mr-sm-2" for="inlineFormCustomSelectPref">Member</label>

                                 <select name='select_name' class="custom-select mb-2 mr-sm-2 mb-sm-0" id="inlineFormCustomSelectPref">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 </select>
                                 <button type="submit" class="btn btn-primary">Add</button>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <!-- Page Footer-->
               <footer class="main-footer">
                  <div class="container-fluid">
                     <div class="row">
                        <div class="col-sm-6">
                           <p>Your company &copy; 2017-2019</p>
                        </div>
                        <div class="col-sm-6 text-right">
                           <p>Design by <a href="https://bootstrapious.com/admin-templates" class="external">Bootstrapious</a></p>
                           <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                        </div>
                     </div>
                  </div>
               </footer>
            </div>
         </div>
      
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>