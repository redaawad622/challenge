<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Letter of Guarantee</title>
      <link href="https://fonts.googleapis.com/css?family=Mirza" rel="stylesheet">
      <link href="../css/bootstrap.css" rel="stylesheet">
      <link href="../css/forms.css" rel="stylesheet">
      <link rel="stylesheet" href="../css/form/blackStyle-them.css">
      <link href="../css/font-awesome.css" rel="stylesheet">
      <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
      <![endif]-->
   </head>
   <body>
      <section class="option-box">
         <div class="color-option">
            <h4>Color option</h4>
            <ul class="list-unstyled">
               <li style="background:#000" data-value="../css/form/blackStyle-them.css"></li>
               <li data-value="../css/form/pinkStyle-them.css"></li>
               <li data-value="../css/form/blueStyle-them.css"></li>
               <li data-value="../css/form/seaStyle-them.css"></li>
               <li data-value="../css/form/greenStyle-them.css"></li>
               <li data-value="../css/form/violetStyle-them.css"></li>
            </ul>
         </div>
         <i class="fa fa-gear fa-3x gear-ch"></i>
      </section>
      <section class="bod">
         <form action="letter" method="post">
         <?php echo e(csrf_field()); ?>

            <div class="container-fluid">
               <h5 class="padding">مستشفي الأطفال الجامعي</h5>
               <h5 class="padding">جامعة المنصورة</h5>
               <h5> اخطار الترسية الخاصة بالممارسة العامة لتوريد</h5>
               <hr>
               <div class="row">
                  <div class="col-md-1">
                     <h4 class="center padding-lg"> رقم البلد </h4>
                     <div class="form-group">
                        <input type="text" name="cityNum" class="form-control">
                     </div>
                  </div>
                  <div class="col-md-3">
                     <h4 class="center padding-lg">الصنف</h4>
                     <div class="form-group">
                        <input type="text" name="category" class="form-control">
                     </div>
                  </div>
                  <div class="col-md-1">
                     <h4 class="center padding-lg">  الوحدة</h4>
                     <div class="form-group">
                        <input type="text" name="unit" class="form-control">
                     </div>
                  </div>
                  <div class="col-md-2">
                     <h4 class="center padding-lg">الكمية الاجمالية</h4>
                     <div class="form-group">
                        <input type="text" name="totalQ" class="form-control">
                     </div>
                  </div>
                  <div class="col-md-2">
                     <h4 class="center padding">الكمية التي تم ترسيتها للشركة</h4>
                     <div class="form-group">
                        <input type="text" name="recievedQ" class="form-control">
                     </div>
                  </div>
                  <div class="col-md-1">
                     <h4 class="center padding-lg">السعر</h4>
                     <div class="form-group">
                        <input type="text" name="price"  class="form-control">
                     </div>
                     <h4 class="center">الاجمالي </h4>
                  </div>
                  <div class="col-md-2">
                     <h4 class="center padding-lg">الاجمالي </h4>
                     <div class="form-group">
                        <input type="text" name="total" class="form-control">
                     </div>                    
                     <div class="form-group">
                        <input type="text"  class="form-control" placeholder="الاجمالي">
                     </div>
                  </div>
               </div>
               <hr>
               <h5 class="padding-r-md" > السيد الدكتور/ مدير فرع المنصورة </h5>
               <h5 class="center"> بعد التحية,</h5>
               <h5 class="center padding-l-xl">برجاء اتخاذ الازم نحو :</h5>
               <h5 class="padding-r-md" > 1- سداد قيمة التأمين النهائي 00000 </h5>
               <div class="form-inline padding-r-xl">
                  <div class="form-group">
                     <label class="bold " for="inputPassword6">علما بأن خطاب الضمان الابتدئي رقم س ق </label>
                     <input type="text" id="inputPassword6" class="form-control mx-sm-3">
                     <label class="bold  padding-r" for="inputPassword6">بنك</label>
                     <input type="text" id="inputPassword6" class="form-control mx-sm-3">
                     <label class="bold  padding-r" for="inputPassword6">قمته</label>
                     <input type="text" id="inputPassword6" class="form-control mx-sm-3">
                     <label class="bold  padding-r" for="inputPassword6">جنيه</label>
                     <label class="bold  padding-r" for="inputPassword6">و ينتهي في</label>
                     <input type="date" id="inputPassword6" class="form-control mx-sm-3">
                  </div>
               </div>
               <h5 class="padding-r-md" > 2- توفير مشمول البضاعة مختومة عطاءات </h5>
               <br>
               <h5 class="padding-r-md" > *مرفق صورة من اخطار الترسية. </h5>
               <h5 class="padding-r-md" > *مرفق طلب خطاب الضمان النهائي للممارسة. </h5>
               <hr>
               <h5 class="padding-r-lg">د.أسامة عبد العليم علي</h5>
               <br>  
               <h5 class="padding-r-lg " >مدير دعاية الفريق الخامس</h5>
               <br>
            </div>
            <input type="submit"  class="btn btn-primary mr-3" value="ارسال">
         </form>
      </section>
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
      <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
      <script src="../js/jquery.nicescroll.min.js"></script>
      <script  src="../js/myjs.js" type="text/javascript">  </script>
   </body>
</html>