<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=600">

      <title>My Website</title>
      <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet">
      <link href="http://fonts.googleapis.com/css?family=Roboto" rel='stylesheet' type='text/css'>
      <link rel="stylesheet" href="<?php echo e(asset('css/normalize.min.css')); ?>">
      <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
      <link rel="stylesheet" href="<?php echo e(asset('css/hover.css')); ?>">
      <link href="<?php echo e(asset('css/homeStyle.css')); ?>" rel="stylesheet">
      <link href="<?php echo e(asset('css/defaultStyle-them.css')); ?>" rel="stylesheet">
      <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
      <link href="<?php echo e(asset('css/font-awesome.css')); ?>" rel="stylesheet">

      
   </head>
   <body>

   <!-- start first logo -->

   <section class="logo">
      <div class="container">
         <div class="row">
            <div class="logos col-lg-9  col-md-6 col-sm-12 col-xs-12">
               <img src="image/rsz_preview.jpg" class="img-responsive">
               <p>CHALLENGE<br> TEAM</p>
            </div>
            <div class="searching col-lg-3 col-md-6 col-sm-12 col-xs-12 text-center">
               <i class="fa fa-google-wallet"></i>
               <i class="fa fa-instagram"></i>
               <i class="fa fa-twitter"></i>
               <i class="fa fa-telegram"></i>
               <i class="fa fa-linkedin"></i>
            </div>
         </div>
      </div>
   </section>

   <!-- end first logo -->
      <!--end scroll-top-->
      <!--section setting option-->
      <section class="option-box">
         <div class="color-option">
            <h4>Color option</h4>
            <ul class="list-unstyled">
               <li data-value="<?php echo e(asset('css/defaultStyle-them.css')); ?>"></li>
               <li data-value="<?php echo e(asset('css/pinkStyle-them.css')); ?>"></li>
               <li data-value="<?php echo e(asset('css/blueStyle-them.css')); ?>"></li>
               <li data-value="<?php echo e(asset('css/seaStyle-them.css')); ?>"></li>
               <li data-value="<?php echo e(asset('css/greenStyle-them.css')); ?>"></li>
               <li data-value="<?php echo e(asset('css/violetStyle-them.css')); ?>"></li>
            </ul>
         </div>
         <i class="fa fa-gear fa-3x gear-ch hvr-sink"></i>
      </section>
      <!--Start main nav-->
      <section class="main-nav fixed-top">
         <ul class="nav d-none"  id="nevo">
            <li class="nav-item active">
               <a class="nav-link  hvr-shrink " href="#event">Events <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
               <a class="nav-link hvr-shrink" href="#medications">Medications</a>
            </li>
            <li class="nav-item">
               <a class="nav-link hvr-shrink" href="#objective">Objectiv</a>
            </li>
            <li class="nav-item">
               <a class="nav-link hvr-shrink" href="#gallery">Gallery</a>
            </li>
            <li class="nav-item">
               <a class="nav-link hvr-shrink" href="#about">About</a>
            </li>
            <li class="nav-item">
               <a class="nav-link hvr-shrink" href="#contact">Contact</a>
            </li>
            

            <?php if(Auth::check()): ?>

            <li class="nav-item">
               <a class="nav-link hvr-shrink" href="/profile"><?php echo e(Auth::user()->name); ?></a>
            </li>

            <li class="nav-item">
               <a class="nav-link hvr-shrink" href="/logout">Logout</a>
            </li>
             <li class="nav-item">
               <a class="nav-link hvr-shrink" href="/home"><i class="fa fa-home fa-lg"></i></a>
            </li>


           <?php else: ?>
           <li class="nav-item">
               <a class="nav-link hvr-shrink" href="#register">Register</a>
            </li>
          
          <li class="nav-item">
          <a class="nav-link hvr-shrink" href="#" data-toggle="modal" data-target="#exampleModal">Login</a>
          </li>

           <?php endif; ?>

            <?php if(Auth::check()&&Auth::user()->hasRole('admin')): ?>
               <li class="nav-item">
                  <a class="nav-link hvr-shrink" href="/admin">Admin</a>
               </li>
            <?php endif; ?>
            
         </ul>
      </section>
      <!-- end main nav-->
      <!--start nav2-->
      <section class="fixed-top">
         <div class="dro">
            <div class="dropdown">
               <button onclick="myFunction()" class="dropbtn"><i class="fa fa-chevron-down" aria-hidden="true"></i> MENU</button>
               <div id="myDropdown" class="dropdown-content">
                  <a class="nav-link hvr-shrink" href="#event">Events <span class="sr-only">(current)</span></a>
                  <a class="nav-link hvr-shrink" href="#medications">Medications</a>
                  <a class="nav-link hvr-shrink" href="#objective">Objectiv</a>
                  <a class="nav-link hvr-shrink" href="#gallery">Gallery</a>
                  <a class="nav-link hvr-shrink" href="#about">About</a>
                  <a class="nav-link hvr-shrink" href="#contact">Contact</a>
                  <?php if(Auth::check()): ?>
                  <a class="nav-link hvr-shrink" href="/profile" <?php if(Auth::user()->hasRole('admin')): ?> style="display: none;"  <?php endif; ?>><?php echo e(Auth::user()->name); ?></a>
                  <a class="nav-link hvr-shrink" href="/logout">Logout</a>
                  <a class="nav-link hvr-shrink" href="/home"><i class="fa fa-home fa-lg"></i></a>

                  <?php else: ?>
                  <a class="nav-link hvr-shrink" href="#register">Register</a>
                  <a href="#" data-toggle="modal" data-target="#exampleModal">Login</a>
                   <?php endif; ?>
                  <?php if(Auth::check()&&Auth::user()->hasRole('admin')): ?>
                     <li class="nav-item">
                        <a class="nav-link hvr-shrink" href="/admin">Admin</a>
                     </li>
                  <?php endif; ?>
               </div>
            </div>
         </div>
      </section>
      <!-- end nav2-->
      <!--Start carousel-->
      <!--<section class="carous">
         <div class="data">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-4">
                     <div class="brand">
                        <img src="image/rsz_preview.jpg" alt="logo">
                        <br>
                        <span>My Website</span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>-->
      <!-- end section carousel-->
      <!--start section event-->
      <section class="event" id="event">
         <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
               <span data-target="#carouselExampleIndicators" data-slide-to="0" class="active">22<br> jan &nbsp; &nbsp; <i class="fa fa-star" aria-hidden="true"></i> <br> <time>7:00 pm</time> </span>
               <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <span data-target="#carouselExampleIndicators" data-slide-to="<?php echo ($key+1);?>"><?php echo date('d',strtotime($event->date));?><br> <?php echo date('F',strtotime($event->date));?> &nbsp; &nbsp; <i class="fa fa-star" aria-hidden="true"></i>  <br> <time><?php echo date('H:i a',strtotime($event->time));?></time></span>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ol>
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <img class="d-block w-100" src="image/1506893028.jpg" alt="First slide">
                  <div class="carousel-caption wow zoomIn" data-wow-duration="3s" data-wow-offset="0">
                     <h3>Here Is The Event Title</h3>
                     <p>Here Is The Event Subject Example Use data attributes to easily control the position of the carousel. data-slide accepts the keywords prev or next, which alters the slide position relative to its current position. Alternatively, use data-slide-to to pass a </p>
                  </div>
               </div>
               <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="carousel-item">
                  <?php if(Auth::check()&&Auth::user()->hasRole('admin')): ?>
                     <a href="/removeEvent/<?php echo e($event->id); ?>"> <i class="fa fa-times fa-2x" aria-hidden="true" style="z-index: 9999;position: absolute;float: right; left: 80%"></i></a>
                  <?php endif; ?>
                  <img class="d-block w-100" src="<?php echo e(asset('image/'.$event->url)); ?>" alt="Second slide">
                  <div class="carousel-caption wow zoomIn" data-wow-duration="3s" data-wow-offset="0">
                     <h3><?php echo e($event->title); ?></h3>
                     <p><?php echo e($event->description); ?></p>
                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
            </a>
         </div>
      </section>
      <!--end section event-->
      <!--start section medications-->
      <section class="posts text-center" id="medications">
         <h1>Gallery</h1>
         <div class="container-fluid">
            <div class="row">
               <div class="MultiCarousel" data-items="1,3,5,6" data-slide="1" id="MultiCarousel" data-interval="1000">
                  <div class="MultiCarousel-inner">
                     <?php $__currentLoopData = $medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="item">
                        <div class="pad15">
                           <?php if(Auth::check()&&Auth::user()->hasRole('admin')): ?>
                              <a href="/removeMedication/<?php echo e($medication->id); ?>"> <i class="fa fa-times fa-2x" aria-hidden="true" style="position: relative;float: right;"></i></a>
                           <?php endif; ?>
                           <img src="image/<?php echo e($medication->url); ?>" class="img-fluid" alt="Responsive image">
                           <div class="post">
                              <h2><time itemprop="startDate" content="2016-04-21T20:00" datetime="01-01"><?php echo e($medication->created_at->toFormattedDateString()); ?></time><a itemprop="name" title="post 2" href="#"><?php echo e($medication->title); ?></a></h2>
                              <p><?php echo e($medication->description); ?></p>
                              <i class="fa fa-medkit fa-lg" aria-hidden="true"></i> &nbsp;
                              <i class="fa fa-plus-square fa-lg" aria-hidden="true"></i>
                           </div>
                        </div>
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <div class="item">
                        <div class="pad15">
                           <img src="image/addiction-71576_640.jpg" class="img-fluid" alt="Responsive image">
                           <div class="post">
                              <h2>
                                 <time itemprop="startDate" content="2016-04-21T20:00" datetime="01-01">30 Jan 2015</time>
                                 <a itemprop="name" title="post 1" href="#">Not So Long Title</a>
                              </h2>
                              <p>Synopsis or short description. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh.</p>
                              <i class="fa fa-medkit fa-lg" aria-hidden="true"></i> &nbsp;
                              <i class="fa fa-plus-square fa-lg" aria-hidden="true"></i>
                           </div>
                        </div>
                     </div>
                     
                     <div class="item">
                        <div class="pad15">
                           <img src="image/tablets-309742_640.png" class="img-fluid" alt="Responsive image">
                           <div class="post">
                              <h2>
                                 <time itemprop="startDate" content="2016-04-21T20:00" datetime="01-01">30 Jan 2015</time>
                                 <a itemprop="name" title="post 1" href="#">Not So Long Title</a>
                              </h2>
                              <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec id elit non mi porta gravida at eget metus. Aenean lacinia bibendum nulla sed consectetur.</p>
                             <i class="fa fa-medkit fa-lg" aria-hidden="true"></i> &nbsp;
                              <i class="fa fa-plus-square fa-lg" aria-hidden="true"></i>
                           </div>
                        </div>
                     </div>
                     
                     
                  </div>
                  <i class="fa fa-chevron-left fa-lg  leftLst  hvr-icon-grow" aria-hidden="true"></i>
                  <i class="fa fa-chevron-right fa-lg rightLst hvr-icon-grow" aria-hidden="true"></i>
               </div>
            </div>
         </div>
      </section>
      <!--end section medications-->
      <!--start section objective-->
      <section class="objective" id="objective">
         <div class="container">
            <div class="row">
               <div class="col-sm-7">
                  <div class="jumb jumbotron-fluid wow rubberBand" data-wow-duration="2s" data-wow-offset="500">
                     <h2 class="display-3">Our Objective</h2>
                     <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
                     <hr class="my-4">
                     <?php $__currentLoopData = $objectives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <p><?php echo e($object->body); ?><?php if(Auth::check()&&Auth::user()->hasRole('admin')): ?>
                           <a href="/removeobject/<?php echo e($object->id); ?>"> <i class="fa fa-times fa-2x" aria-hidden="true" style="position: relative;right:20px;z-index:555;float: right;"></i></a>
                        <?php endif; ?></p>
                     <hr class="my-4">
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <p class="lead">
                        <a class="btn btn-danger btn-md hvr-float-shadow " href="#" role="button">Read more</a>
                     </p>
                  </div>
               </div>
               <div class="col-sm-5 text-center">
                  <img src="image/icon-about-homepage-infrastructure.png">
               </div>
            </div>
         </div>
      </section>
      <!--end section objective-->
      <!--start section gallery-->
      <section class="gallery" id="gallery">
         <h1>Gallery</h1>
         <div class="container-fluid">
            <div class="row">
               <div class="MultiCarousel" data-items="1,3,5,6" data-slide="1" id="MultiCarousel" data-interval="1000">
                  <div class="MultiCarousel-inner">
                     <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="item">
                        <?php if(Auth::check()&&Auth::user()->hasRole('admin')): ?>
                           <a href="/removegallery/<?php echo e($gallery->id); ?>"> <i class="fa fa-times fa-2x" aria-hidden="true" style="position: relative;right:20px;z-index:555;float: right;"></i></a>
                        <?php endif; ?>


                        <div class="pad15">

                           <img class="ca-img" <?php if(Auth::check()&&Auth::user()->hasRole('admin')): ?> style="position: relative;bottom: 12px;" <?php endif; ?> src="image/<?php echo e($gallery->url); ?>" alt="First slide">
                        </div>


                     </div>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <div class="item">
                        <div class="pad15">
                           <img class="ca-img" src="image/beard-1850932_640.jpg" alt="First slide">
                        </div>
                     </div>
                     <div class="item">
                        <div class="pad15">
                           <img class="ca-img" src="image/people-2560033_640.jpg" alt="First slide">
                        </div>
                     </div>
                     
                     
                  </div>
                  <i class="fa fa-chevron-left fa-lg  leftLst hvr-icon-grow" aria-hidden="true"></i>
                  <i class="fa fa-chevron-right fa-lg rightLst hvr-icon-grow" aria-hidden="true"></i>
               </div>
            </div>
         </div>
      </section>
      <!--end section gallery-->
      <!--start section register-->
      <section class="register" id="register">
         <h1 class="wow fadeInUpBig" data-wow-duration="2.5s" data-wow-offset="300" style="margin-bottom: 30px;">Register</h1>
         <div class="container">
            <form action="/" method="post"  enctype="multipart/form-data" >
                   <?php echo e(csrf_field()); ?>

               <div class="row">
                
                  <div class="col-sm-6 ">
                     <div class="form-group wow fadeInLeftBig" data-wow-duration="2s" data-wow-offset="300" data-wow-delay=".5s">
                        <label for="exampleInputtext" style="color: #555;font-weight: bold;">Name</label>
                        <input class="form-control <?php if ($errors->has('name')) {echo 'is-invalid';} ?>" name="name" type="text" placeholder="Name" required>
                        <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($message); ?>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                     <div class="form-group wow fadeInLeftBig" data-wow-duration="2s" data-wow-offset="300" data-wow-delay="1s">
                        <label for="exampleInputEmail1" style="color: #555;font-weight: bold;">Email address</label>
                        <input type="email" name="email" class="form-control <?php if ($errors->has('email')){echo 'is-invalid';} ?>" id="validationCustom01" aria-describedby="emailHelp" placeholder="Enter email" required>

                        <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($message); ?>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        
                     </div>
                     <div class="form-group wow fadeInLeftBig" data-wow-duration="2s" data-wow-offset="300" data-wow-delay="1.5s">
                        <label for="exampleInputtext" style="color: #555;font-weight: bold;">file.Nu</label>
                        <input class="form-control  <?php if ($errors->has('file_num')) {echo 'is-invalid';} ?>" name="file_num" type="text" placeholder="file number" required>
                        <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('file_num'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($message); ?>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-6">
                     <div class="form-group  wow fadeInRightBig" data-wow-duration="2s" data-wow-offset="300" data-wow-delay=".5s">
                        <label for="exampleInputPassword1" style="color: #555;font-weight: bold;">Password</label>
                        <input type="password" name="password" class="form-control <?php if ($errors->has('password')) {echo 'is-invalid';} ?> " id="exampleInputPassword1" placeholder="Password" required>
                        <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($message); ?>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                     <div class="form-group  wow fadeInRightBig" data-wow-duration="2s" data-wow-offset="300" data-wow-delay="1s">
                        <label for="exampleInputPassword2" style="color: #555;font-weight: bold;">Confirm Password</label>
                        <input type="password" name="password_confirmation" class="form-control <?php if ($errors->has('password_confirmation')) {echo 'is-invalid';}?>" id="exampleInputPassword1" placeholder="Confirm Password" required>
                        <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('password_confirmation'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($message); ?>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                     <div class="form-group wow fadeInRightBig" data-wow-duration="2s" data-wow-offset="300" data-wow-delay="1.5s">
                          <label for="exampleFormControlFile1" style="color: #555;font-weight: bold;">Choose image</label>
                        <input type="file" accept="image/*" name="url" class="form-control-file <?php if ($errors->has('url')) {echo 'is-invalid';} ?>" id="exampleFormControlFile1">
                        <div class="invalid-feedback">
                           <?php $__currentLoopData = $errors->get('url'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($message); ?>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                  </div>
                  
               </div>
               <button type="submit" class="btn btn-danger hvr-float-shadow wow fadeInLeftBig" data-wow-duration="2s" data-wow-offset="300" data-wow-delay="2s">Submit</button>
            </form>


                     </div>
                  </div>
              

         </div>


      </section>
      <!--end section register-->
      <!--start section About-->
      <section class="about" id="about">
         <div class="container-fluid">
            <h1>About</h1>
            <div class="row">
               <div class="col-lg-6 col-sm-12">
                  <div class="box">
                     <div class="row">
                        <div class="img-holder">
                           <div class="col-xs-3">
                              <div class="icon-holder">
                              </div>
                           </div>
                           <div class="col-xs-9">
                              <div class="descr  wow rollIn" data-wow-duration="2s" data-wow-offset="300">
                                 <h2>Our Strategy </h2>
                                 <p class="lead text-center">
                                    Our Strategic capability is concerned with the unique high capacity resources and competences that deliver value to our customers through high quality drugs with competitive price.
                                 </p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-12">
                  <div class="box">
                     <div class="row">
                        <div class="img-holder">
                           <div class="col-xs-3">
                              <div class="icon-holder">
                              </div>
                           </div>
                           <div class="col-xs-9">
                              <div class="descr  wow rollIn" data-wow-duration="2s" data-wow-offset="300">
                                 <h2>Our Purpose </h2>
                                 <p class="lead text-center">
                                    We will provide pharmaceutical generic drug products and its services of superior quality and value that improve the lives of the world’s consumers, now and for generations to come. As a result, consumers will reward us with leadership sales, profit and value creation, allowing our people, our shareholders, and the communities in which we live and work to prosper
                                 </p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--end section about-->
      <!--start section contact us-->
      <section class="contact" id="contact">
         <div class="container">
            <h1>Contact Us</h1>
            <div class="row">
               <div class="col-lg-4 col-sm-12">
                  <div class="descr">
                     <h2>contact admin</h2>
                     <p class="mail">mohamed-ahmed@gmail.com</p>
                     <p>0110054451545</p>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-12">
                  <div class="descr">
                     <h2>contact company</h2>
                     <p class="mail">mohamed-ahmed@gmail.com</p>
                     <p>0110054451545</p>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-12">
                  <div class="descr">
                     <h2>public contact</h2>
                     <p class="mail">mohamed-ahmed@gmail.com</p>
                     <p>0110054451545</p>
                  </div>
               </div>
            </div>
            <br>
            <hr>
            <div class="scial text-center">
               <i class="fa fa-facebook-square fa-2x in" aria-hidden="true"></i>
               <i class="fa fa-twitter-square fa-2x in" aria-hidden="true"></i>
               <i class="fa fa-google-plus-square fa-2x in" aria-hidden="true"></i>
            </div>
            <span>&copy; 2017.All Rights Reserved</span>
         </div>
      </section>
      <!--end section contact us-->
      <!-- model login-->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Login</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <form method="post" action="/login">
                     <?php echo e(csrf_field()); ?>

                     <div class="form-group">
                        <label for="exampleInputEmail1">Email address</label>
                        <input type="email" name="email" class="form-control  <?php  if($errors->any()) {echo 'is-invalid';}?>" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>


                     </div>
                     <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password" name="password" class="form-control  <?php if($errors->any()) {echo 'is-invalid';}?> " id="exampleInputPassword1" placeholder="Password" required>

                        <div class="invalid-feedback">
                           <?php if($errors->any()): ?>
                              <?php echo e($errors->first()); ?>

                           <?php endif; ?>
                        </div>
                     </div>
                     <div class="form-check">
                        <label class="form-check-label">
                        <input type="checkbox" name="checked" class="form-check-input"> Remember me
                        </label>
                     </div>
                     <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Login</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <!--start scroll-top-->
      <div class="scroll">
         <i class="fa fa-arrow-circle-up fa-3x hvr-pulse" aria-hidden="true"></i>
      </div>
      <!--section loading-->
      <section class="overlay">
         <div class="sk-cube-grid">
            <div class="sk-cube sk-cube1"></div>
            <div class="sk-cube sk-cube2"></div>
            <div class="sk-cube sk-cube3"></div>
            <div class="sk-cube sk-cube4"></div>
            <div class="sk-cube sk-cube5"></div>
            <div class="sk-cube sk-cube6"></div>
            <div class="sk-cube sk-cube7"></div>
            <div class="sk-cube sk-cube8"></div>
            <div class="sk-cube sk-cube9"></div>
         </div>
      </section>
       <script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="<?php echo e(asset('js/popper.min.js')); ?>" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
      <script src='<?php echo e(asset('js/jquery-2.2.2.min.js')); ?>'></script>
      <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
      <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
      <script>
         new WOW().init();
      </script>
      <script src="<?php echo e(asset('js/jquery.nicescroll.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/myjs.js')); ?>" type="text/javascript"></script>



   </body>
</html>