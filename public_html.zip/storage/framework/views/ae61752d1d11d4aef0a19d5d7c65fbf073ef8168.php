<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>daliy Report</title>
      <link href="https://fonts.googleapis.com/css?family=Mirza" rel="stylesheet">
      <link href="../css/bootstrap.css" rel="stylesheet">
      <link href="../css/forms.css" rel="stylesheet">
      <link rel="stylesheet" href="../css/form/blackStyle-them.css">
      <link href="../css/font-awesome.css" rel="stylesheet">
      <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
      <![endif]-->
   </head>
   <body>
      <section class="option-box">
         <div class="color-option">
            <h4>Color option</h4>
            <ul class="list-unstyled">
               <li style="background:#000" data-value="../css/form/blackStyle-them.css"></li>
               <li data-value="../css/form/pinkStyle-them.css"></li>
               <li data-value="../css/form/blueStyle-them.css"></li>
               <li data-value="../css/form/seaStyle-them.css"></li>
               <li data-value="../css/form/greenStyle-them.css"></li>
               <li data-value="../css/form/violetStyle-them.css"></li>
            </ul>
         </div>
         <i class="fa fa-gear fa-3x gear-ch"></i>
      </section>
      <section class="bod">
         <form action="daliyReport" method="post">
        <?php echo e(csrf_field()); ?>

            <div class="container">
               <h3> <span class="padding-r-xl"> الشركة المصرية الدولية للصناعات الدوائية - ايبيكو</span> <span class="left" >القطاع التجاري-فرع المنصورة<br><br><img class="padding-r-lg" src="../image/LogoImageMasterPage.jpg"> </span></h3>
               <h3>   السيد الدكتور/ مدير دعاية الفريق الأول</h3>
               <br>
               <h3 class="center padding-r-xl"> تحية طيبة وبعد.......,</h3>
               <br>
               <h3>  مقدمه لسيادتكم دكتور/ </h3>
               <h3 class="left" >مشرف دعايه الفريق / الأول</h3>
               <br><br>
               <div class="form-inline right">
                  <div class="form-group">
                     <label class="bold p" for="inputPassword6">تقرير عمل عن  يوم </label>
                     <input type="text" id="inputPassword6" class="form-control mx-sm-3" value="<?php echo date('l',time())?>">
                  </div>
               </div>
               <div class="form-inline left">
                  <div class="form-group">
                     <label class="bold p" for="inputPassword6">الموافق</label>
                     <input type="text" id="inputPassword6" value="<?php echo date('d /m /Y',time())?>" class="form-control mx-sm-3">
                  </div>
               </div>
               <br>
               <br><br>
               <div class="display">
                  <h4 class="m-t-sm">-:الصباحي</h4>
                  <div class="form-inline m-r">
                     <div class="form-group ">
                        <label class="bold p">مع دكتور</label>
                        <input type="text" value="<?php echo e(Auth::user()->name); ?>" id="inputPassword6" class="form-control mx-sm-3">
                        <input type="text" id="inputPassword6" class="form-control mx-sm-3" value="كم">
                     </div>
                  </div>
               </div>
               <hr>
               <div class="row">
                  <div class="col-sm-5">
                     <h4 class="center padding-lg">اسم الجهة</h4>
                     <div class="form-group">
                        <input type="text" name="dirName"  class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-3">
                     <h4 class="center">عدد الأطباء</h4>
                     <div class="row">
                        <div class="col-sm-6">
                           <!--left-->
                           <h4 class="center"> طبيب </h4>
                           <div class="form-group">
                              <input type="text" name="doctor" class="form-control " >
                           </div>
                        </div>
                        <div class="col-sm-6">
                           <h4 class="center"> صيدلي </h4>
                           <div class="form-group">
                              <input type="text" name="pharmacian" class="form-control " >
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <h4 class="center padding-lg">  صيدليات </h4>
                     <div class="form-inline  padding  padding-r-xl">
                        <div class="form-group">
                           <label class="bold">ص1</label>
                           <input type="text" name="pharmacy"  class="form-control mx-sm-3">
                        </div>
                     </div>
                  </div>
               </div>
               <div class="display">
                  <h4 class="m-t-sm">-:المسائي</h4>
                  <div class="form-inline m-r">
                     <div class="form-group ">
                        <label class="bold p" >مع دكتور</label>
                        <input type="text" id="inputPassword6" class="form-control mx-sm-3">
                        <input type="text" id="inputPassword6" class="form-control mx-sm-3" value="كم">
                     </div>
                  </div>
               </div>
               <hr>
               <div class="row">
                  <div class="col-sm-1">
                     <h4 class="center">  .م </h4>
                     <h4 class="center padding-md"> 1 </h4>
                  </div>
                  <div class="col-sm-4">
                     <h4 class="center"> اسم الطبيب</h4>
                     <div class="form-group">
                        <input type="text" name="doctorName" class="form-control " >
                     </div>
                  </div>
                  <div class="col-sm-2">
                     <h4 class="center">التخصص</h4>
                     <div class="form-group">
                        <input type="text" name="special"  class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-2">
                     <h4 class="center">الكود</h4>
                     <div class="form-group">
                        <input type="text" name="kode" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-3">
                     <h4 class="center">ملاحظات</h4>
                     <div class="form-group">
                        <input type="text" name="note" class="form-control " >
                     </div>
                  </div>
               </div>

               <h4 > -:ملاحظات عامة</h4>
               <hr>
               <div class="row">
                  <div class="col-sm-12">
                     <div class="form-group">
                        <textarea class="form-control" name="publicNote" id="exampleFormControlTextarea1" rows="3"></textarea>
                     </div>
                  </div>
               </div>
               <hr>
               <h3 class="padding-md">مقدم لسيادتكم<span class="left" >مدير دعاية الفريق الأول</span></h3>
            </div>
            <input type="submit"  class="btn btn-primary mr-3" value="ارسال">
         </form>
      </section>
      <script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="<?php echo e(asset('js/popper.min.js')); ?>" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
      <script src='<?php echo e(asset('js/jquery-2.2.2.min.js')); ?>'></script>
      <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
      <script src="../js/jquery.nicescroll.min.js"></script>
      <script  src="../js/myjs.js" type="text/javascript">  </script>
   </body>
</html>