<?php $__env->startSection('content'); ?>

    <div class="container">
        <!-- Start private instruction form-->


        <div class="statistic  align-items-center bg-white has-shadow">
            <h3>private instruction</h3>
            <form method="post" action="/inst" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Message content</label>
                    <textarea class="form-control <?php if ($errors->has('body')){echo 'is-invalid';} ?>" name="body" value="<?php echo e(old('body')); ?>" id="exampleFormControlTextarea1" rows="3"></textarea>
                    <div class="invalid-feedback">
                        <?php $__currentLoopData = $errors->get('body'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlFile1">Medication picture</label>
                    <input type="file" class="form-control-file <?php if ($errors->has('url')){echo 'is-invalid';} ?>" name="url" id="exampleFormControlFile1">
                    <div class="invalid-feedback">
                        <?php $__currentLoopData = $errors->get('url'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <label class="mr-sm-2" for="inlineFormCustomSelectPref">Member</label>

                <select name='select_name' class="custom-select mb-2 mr-sm-2 mb-sm-0" id="inlineFormCustomSelectPref">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                <button type="submit" class="btn btn-primary">Add</button>
            </form>
        </div>
        <!-- end private instruction form-->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>