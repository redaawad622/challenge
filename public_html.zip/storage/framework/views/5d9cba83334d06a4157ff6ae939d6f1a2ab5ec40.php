<?php $__env->startSection('content'); ?>

    <div class="container">
        <!-- Add Gallery Picture form -->

        <div class="statistic  align-items-center bg-white has-shadow" id="gallery">
            <h3>Add Gallery Picture</h3>
            <form method="post" action="/img" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="exampleFormControlFile1">choose picture</label>
                    <input type="file" class="form-control-file <?php if ($errors->has('MUrl')){echo 'is-invalid';} ?>" name="MUrl" id="exampleFormControlFile1" required>
                    <div class="invalid-feedback">
                        <?php $__currentLoopData = $errors->get('MUrl'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
            </form>
        </div>
        <!--end  Add Gallery Picture form -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>