<?php $__env->startSection('profile'); ?>

    <section id="cv">
        <div>
            <div class="row">


                <div class="col-sm-4">
                    <div class="pref">
                        <div class="content">
                            <div class="name">

                                <h1><?php echo e(Auth::user()->name); ?></h1>
                                <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($cv->job_title)): ?>
                                        <h2> <?php echo e($cv->job_title); ?></h2>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                        <div class="info">
                            <div class="info-h">
                                <h2>Personal Data</h2>

                            </div>
                            <div class="email">
                                <h4>E-mail</h4>
                                <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($cv->pr_email)): ?>
                                        <p><?php echo e($cv->pr_email); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <h4>Adress</h4>
                                <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($cv->pr_adress)): ?>
                                        <p><?php echo e($cv->pr_adress); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <h4>Contact</h4>
                                <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($cv->pr_contact)): ?>
                                        <p><?php echo e($cv->pr_contact); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <h4>Date Of Birth</h4>
                                <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($cv->pr_date_birth)): ?>
                                        <p><?php echo e($cv->pr_date_birth); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <h4>Marital Status</h4>
                                <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($cv->pr_marital_status)): ?>
                                        <p><?php echo e($cv->pr_marital_status); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <h4>File Num</h4>
                                <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($cv->pr_file_number)): ?>
                                        <p><?php echo e($cv->pr_file_number); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>


                        <div class="skill">

                            <div class="skill-h">
                                <h2>Professional Skills</h2>

                            </div>
                            <div class="skill-o">
                                <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($cv->sk_name)): ?>
                                        <h4><?php echo e($cv->sk_name); ?></h4>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-sm-8">
                    <div class="content-2">
                        <div class="prg">
                            <h2> Career Objective</h2>

                            <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!empty($cv->summary)): ?>

                                    <p class="p">
                                        <?php echo e($cv->summary); ?>


                                    </p>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                        <div class="prg">
                            <h2>
                                Work Experience and career pathway
                            </h2>
                        </div>
                        <div class="experience">
                            <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!empty($cv->ex_name)): ?>
                                    <div class="expr">
                                    <span>
                                       from <?php echo e(date('m-Y',strtotime($cv->ex_date))); ?>  &nbsp; &nbsp; &nbsp; &nbsp; to <?php echo e(date('m-Y',strtotime($cv->ex_end))); ?>

                                    </span>
                                        <p class="p1"><?php echo e($cv->ex_name); ?> <br> from <?php echo e($cv->ex_place); ?> </p>

                                    </div>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="expr-s">

                                <p style="font-weight: bold;">Responsibilities:</p>
                                <ul style="list-style-type: circle;">
                                    <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!empty($cv->respons)): ?>

                                            <li><?php echo e($cv->respons); ?></li>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                            </div>
                        </div>


                        <div class="prg">
                            <h2>
                                Educational QUALIFICATIONS  And Courses
                            </h2>
                        </div>
                        <div class="education">
                            <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!empty($cv->ed_name)): ?>
                                    <div class="expr">
                                    <span>
                                        from <?php echo e(date('m-Y',strtotime($cv->ed_date))); ?> &nbsp; &nbsp; &nbsp; &nbsp; to <?php echo e(date('m-Y',strtotime($cv->ed_end))); ?>

                                    </span>
                                        <p class="p1"><?php echo e($cv->ed_name); ?><br> from <?php echo e($cv->ed_place); ?> </p>

                                    </div>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>

                    </div>

                </div>

            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/cv.css')); ?>">

<?php $__env->stopPush(); ?>
<?php echo $__env->make('profile.profileLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>