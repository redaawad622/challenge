<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=1200">


   <title>Monthly Report</title>
   <link href="https://fonts.googleapis.com/css?family=Mirza" rel="stylesheet">
   <link href="../css/bootstrap.min.css" rel="stylesheet">
   <link href="../css/forms.css" rel="stylesheet">
   <link rel="stylesheet" href="../css/form/blackStyle-them.css">
   <link href="../css/font-awesome.css" rel="stylesheet">
   <!--[if lt IE 9]>
   <script src="js/html5shiv.min.js"></script>
   <script src="js/respond.min.js"></script>
   <![endif]-->

   <style>
      .sp_input
      {
         border: none;
         border-bottom: 2px dotted;
      }
   </style>

</head>
<body>
<section class="option-box">
   <div class="color-option">
      <h4>Color option</h4>
      <ul class="list-unstyled">
         <li style="background:#000" data-value="../css/form/blackStyle-them.css"></li>
         <li data-value="../css/form/pinkStyle-them.css"></li>
         <li data-value="../css/form/blueStyle-them.css"></li>
         <li data-value="../css/form/seaStyle-them.css"></li>
         <li data-value="../css/form/greenStyle-them.css"></li>
         <li data-value="../css/form/violetStyle-them.css"></li>
      </ul>
   </div>
   <i class="fa fa-gear fa-3x gear-ch"></i>
</section>
<section class="bod container-fluid">
   <form action="/monthlyReport" method="post">
      <?php echo e(csrf_field()); ?>

   <table class="table">
      <tbody>
      <tr>
         <td style="width: 37%;">
            <h3><img style="width: 111px;" src="../image/LogoImageMasterPage.jpg">  الشركة المصرية الدولية للصناعات الدوائية - ايبيكو </h3>
            <h3 class="center">القطاع التجاري<br> المكتب العلمي</h3>
         </td>
         <td>
            <div class="form-inline left">
            <div class="form-group">
               <label class="bold p" for="inputPassword6">تقرير  شهر  </label>
               <input type="text" id="inputPassword6" class="form-control mx-sm-3 " value="<?php use App\Helper\AppHelper;echo date('F',time())?>" disabled>
            </div>
            </div>
         </td>
      </tr>
      <tr>
         <td>
            <div class="form-inline">
               <div class="form-group">
                  <label style="width: 86px;"   class="bold p" for="inputPassword6">  فرع:  </label>
                  <input type="text" name="pranch" id="inputPassword6" class="form-control mx-sm-3 sp_input" required>
               </div>
            </div>

         </td>
         <td  rowspan="3">
            <table class="table table-bordered">
               <thead>
               <tr>
                  <th>البيان</th>
                  <th>أيام العمل</th>
                  <th>أطباء عيادات</th>
                  <th>صيدليات</th>
                  <th>مراكز طبية</th>
                  <th>عدد الأطباء</th>

                  <th>فروع المصرية</th>
               </tr>
               <tr>

               </tr>
               </thead>
               <tbody>
               <tr>
                  <td style="padding-top: 46px;font-weight: bold;"><span >المستهدف</span></td>
                  <td><input style="margin-top: 33px;" name="work_days_pa" type="text" class="form-control"></td>
                  <td><input style="margin-top: 33px;" type="text" name="doctors_clinic_pa" class="form-control"></td>
                  <td><input style="margin-top: 33px;" type="text" name="pharmacy_pa" class="form-control"></td>


                  <td>

                     <div class="row">
                        <div class="col-md-4">
                           <!--left-->
                           <h4 class="center"> هيئات </h4>
                           <div class="form-group">
                              <input type="text" name="station_h_pa" class="form-control <?php if ($errors->has('station_h_pa')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('station_h_pa'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <h4 class="center"> مدارس </h4>
                           <div class="form-group">
                              <input type="text" name="station_m_pa" class="form-control  <?php if ($errors->has('station_m_pa')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('station_m_pa'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <h4 class="center"> وحدات </h4>
                           <div class="form-group">
                              <input type="text" name="station_w_pa" class="form-control  <?php if ($errors->has('station_w_pa')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('station_w_pa'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                     </div>

                  </td>
                  <td>

                     <div class="row">
                        <div class="col-md-4">
                           <!--left-->
                           <h4 class="center"> هيئات </h4>
                           <div class="form-group">
                              <input type="text" name="doctors_num_h_pa" class="form-control <?php if ($errors->has('doctors_num_h_pa')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('doctors_num_h_pa'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <h4 class="center"> مدارس </h4>
                           <div class="form-group">
                              <input type="text" name="doctors_num_m_pa" class="form-control  <?php if ($errors->has('doctors_num_m_pa')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('doctors_num_m_pa'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <h4 class="center"> وحدات </h4>
                           <div class="form-group">
                              <input type="text" name="doctors_num_w_pa" class="form-control  <?php if ($errors->has('doctors_num_w_pa')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('doctors_num_w_pa'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                     </div>

                  </td>
                  </td>
                  <td><input  style="margin-top: 33px;" name="eg_pranch_pa" type="text" class="form-control"></td>


               </tr>
               <tr>

               </tr>

               <tr>
                  <td style="padding-top: 46px;font-weight: bold;"><span >الفعلي</span></td>
                  <td><input style="margin-top: 33px;" name="work_days_ac" id="work_days_ac" type="text" class="form-control"></td>
                  <td><input style="margin-top: 33px;" type="text" name="doctors_clinic_ac" id="doctors_clinic_ac" class="form-control"></td>
                  <td><input style="margin-top: 33px;" type="text" name="pharmacy_ac"  id="pharmacy_ac" class="form-control"></td>


                  <td>

                     <div class="row">
                        <div class="col-md-4">
                           <!--left-->
                           <h4 class="center"> هيئات </h4>
                           <div class="form-group">
                              <input type="text" name="station_h_ac"  id="station_h_ac" class="form-control <?php if ($errors->has('station_h_ac')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('station_h_ac'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <h4 class="center"> مدارس </h4>
                           <div class="form-group">
                              <input type="text" name="station_m_ac" id="station_m_ac" class="form-control  <?php if ($errors->has('station_m_ac')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('station_m_ac'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <h4 class="center"> وحدات </h4>
                           <div class="form-group">
                              <input type="text" name="station_w_ac" id="station_w_ac" class="form-control  <?php if ($errors->has('station_w_ac')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('station_w_ac'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                     </div>

                  </td>
                  <td>

                     <div class="row">
                        <div class="col-md-4">
                           <!--left-->
                           <h4 class="center"> هيئات </h4>
                           <div class="form-group">
                              <input type="text" name="doctors_num_h_ac" id="doctors_num_h_ac" class="form-control <?php if ($errors->has('doctors_num_h_ac')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('doctors_num_h_ac'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <h4 class="center"> مدارس </h4>
                           <div class="form-group">
                              <input type="text" name="doctors_num_m_ac"  id="doctors_num_m_ac" class="form-control  <?php if ($errors->has('doctors_num_m_ac')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('doctors_num_m_ac'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <h4 class="center"> وحدات </h4>
                           <div class="form-group">
                              <input type="text" name="doctors_num_w_ac" id="doctors_num_w_ac" class="form-control  <?php if ($errors->has('doctors_num_w_ac')) {echo 'is-invalid';} ?>">

                              <div class="invalid-feedback">
                                 <?php $__currentLoopData = $errors->get('doctors_num_w_ac'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                     </div>

                  </td>
                  </td>
                  <td><input  style="margin-top: 33px;" name="eg_pranch_ac"  id="eg_pranch_ac" type="text" class="form-control"></td>


               </tr>
               <tr>

               </tr>


               </tbody>
            </table>
         </td>

      </tr>
      <tr>
         <td>
            <div class="form-inline">
               <div class="form-group">
                  <label  class="bold p" for="inputPassword6">  اسم المندوب:  </label>
                  <input type="text" name="name"  id="inputPassword6" class="form-control mx-sm-3 sp_input" required>
               </div>
            </div>

         </td>

      </tr>
      <tr>
         <td>
            <div class="form-inline">
               <div class="form-group">
                  <label style="width: 86px;"   class="bold p" for="inputPassword6">  مقر السكن:  </label>
                  <input type="text"  name="place" id="inputPassword6" class="form-control mx-sm-3 sp_input" required>
               </div>
            </div>

         </td>
      </tr>
      <tr>
         <td>
            <div class="form-inline">
               <div class="form-group">
                  <label style="width: 86px;" class="bold p" for="inputPassword6">  المنطقة:  </label>
                  <input type="text" name="area" id="inputPassword6" class="form-control mx-sm-3 sp_input" required>
               </div>
            </div>

         </td>
         <td rowspan="">
            <table class="table table-bordered">
               <thead>
               <tr>
                  <th>كيلو متر السيارة</th>
                  <th>بداية الشهر</th>
                  <th>نهاية الشهر</th>
                  <th> الاستهلاك</th>
                  <th> المحاسبة علي</th>

               </tr>

               </thead>
               <tbody>
               <tr>
                  <td></td>
                  <td><input  type="text" name="km_start" class="form-control" required></td>
                  <td><input type="text" name="km_end" class="form-control" required></td>
                  <td><input type="text" name="km_consum" class="form-control" required></td>
                  <td><input type="text" name="km_paid" class="form-control" required></td>
               </tr>

               </tbody>
            </table>
         </td>
      </tr>
      </tbody>
   </table>


   <br>




      <table class="table table-bordered">
         <thead>
         <tr>
            <th>التاريخ</th>
            <th> اليوم</th>
            <th colspan="4"> العمل المسائي</th>
            <th colspan="6">العمل الصباحي</th>
            <th style="font-size: 13px;"> فروع الشركة المصرية</th>
            <th  style="font-size: 13px;"> الاستهلاك الفعلي</th>


         </tr>
         <tr>

         </tr>
         </thead>
         <tbody>
         <tr>

            <td></td>
            <td></td>



            <td colspan="4">

               <div class="row">
                  <div class="col-md-4">
                     <!--left-->
                     <h4 class="center"> خط السير </h4>


                  </div>
                  <div class="col-md-4">
                     <h4 class="center"> الأطباء </h4>

                  </div>
                  <div class="col-md-4">
                     <h4 class="center"> صيدليات </h4>

                  </div>
               </div>

            </td>
            <td colspan="6">

               <div class="row">
                  <div class="col-md-4">
                     <!--left-->
                     <h4 class="center"> خط السير </h4>

                  </div>
                  <div class="col-md-4">
                     <h4 class="center"> مراكز طبية </h4>

                  </div>
                  <div class="col-md-4">
                     <h4 class="center"> عدد الأطباء </h4>

                  </div>
               </div>

            </td>


            <td></td>
            <td></td>


         </tr>

         <tr>

            <td></td>
            <td></td>

            <td colspan="4">

            </td>
            <td colspan="6">

               <div class="row">
                  <div class="col-md-4">

                  </div>
                  <div class="col-md-4">
                     <div class="row">
                        <div class="col-md-4">
                          <h6 class="center">ه</h6>
                        </div>
                        <div class="col-md-4">
                          <h6 class="center">م</h6>
                        </div>
                        <div class="col-md-4">
                          <h6 class="center">و</h6>
                        </div>
                     </div>


                  </div>
                  <div class="col-md-4">
                     <div class="row">
                        <div class="col-md-4">
                          <h6 class="center">هيئات</h6>
                        </div>
                        <div class="col-md-4">
                          <h6 class="center">مدارس</h6>
                        </div>
                        <div class="col-md-4">
                          <h6 class="center">وحدات</h6>
                        </div>
                     </div>

                  </div>
               </div>

            </td>


            <td></td>
            <td></td>


         </tr>

         <?php for($i=1;$i<=cal_days_in_month(CAL_GREGORIAN,date('m',time()) , date('Y',time()));$i++): ?>

         <tr>

            <td><input type="text" name="date_num<?php echo e($i); ?>"  value="<?php echo e($i); ?>" class="form-control" disabled></td>
            <td><input type="text" name="day_name<?php echo e($i); ?>" value="<?php

                echo  AppHelper::instance()->dayInArbic(date( 'l', strtotime( date( 'n' ) . '/' . $i ) )) ;?>" class="form-control" disabled></td>

            <td colspan="4">
               <div class="row">
                  <div class="col-md-4">
                     <input name="route_pm<?php echo e($i); ?>" id="route_pm<?php echo e($i); ?>" type="text" class="form-control" required>
                  </div>
                  <div class="col-md-4">
                     <input type="text" id="doctors_pm<?php echo e($i); ?>" name="doctors_pm<?php echo e($i); ?>" class="form-control">
                  </div>
                  <div class="col-md-4">
                     <input type="text"  name="pharma_pm<?php echo e($i); ?>" id="pharma_pm<?php echo e($i); ?>" class="form-control">
                  </div>

               </div>

            </td>
            <td colspan="6">

               <div class="row">
                  <div class="col-md-4">
                     <input type="text" name="route_am<?php echo e($i); ?>" id="route_am<?php echo e($i); ?>" class="form-control" required>

                  </div>
                  <div class="col-md-4">
                     <div class="row">
                        <div class="col-md-4">
                           <input type="text" name="station_h_am<?php echo e($i); ?>" id="station_h_am<?php echo e($i); ?>" class="form-control">
                        </div>
                        <div class="col-md-4">
                           <input type="text" name="station_m_am<?php echo e($i); ?>" id="station_m_am<?php echo e($i); ?>" class="form-control">
                        </div>
                        <div class="col-md-4">
                           <input type="text" name="station_w_am<?php echo e($i); ?>" id="station_w_am<?php echo e($i); ?>" class="form-control">
                        </div>
                     </div>


                  </div>
                  <div class="col-md-4">
                     <div class="row">
                        <div class="col-md-4">
                           <input type="text" name="doctors_num_h_am<?php echo e($i); ?>" id="doctors_num_h_am<?php echo e($i); ?>" class="form-control">
                        </div>
                        <div class="col-md-4">
                           <input type="text" name="doctors_num_m_am<?php echo e($i); ?>"  id="doctors_num_m_am<?php echo e($i); ?>" class="form-control">
                        </div>
                        <div class="col-md-4">
                           <input type="text" name="doctors_num_w_am<?php echo e($i); ?>" id="doctors_num_w_am<?php echo e($i); ?>" class="form-control">
                        </div>
                     </div>

                  </div>
               </div>

            </td>


            <td> <input type="text" name="egption_pranch<?php echo e($i); ?>" id="egption_pranch<?php echo e($i); ?>" class="form-control"></td>
            <td> <input type="text" name="actual_paid<?php echo e($i); ?>" id="actual_paid<?php echo e($i); ?>" class="form-control" required></td>


         </tr>
         <?php endfor; ?>

         <tr>

            <td colspan="2">المجموع</td>

            <td colspan="4">
               <div class="row">
                  <div class="col-md-4">
                  nothing
                  </div>
                  <div class="col-md-4">
                     <input type="text" id="doc" name="doc" class="form-control">
                  </div>
                  <div class="col-md-4">
                     <input type="text" id="ph" name="ph" class="form-control">
                  </div>

               </div>

            </td>
            <td colspan="6">

               <div class="row">
                  <div class="col-md-4">
                   nothing

                  </div>
                  <div class="col-md-4">
                     <div class="row">
                        <div class="col-md-4">
                           <input type="text" id="station_h" name="station_h" class="form-control">
                        </div>
                        <div class="col-md-4">
                           <input type="text" id="station_m" name="station_m" class="form-control">
                        </div>
                        <div class="col-md-4">
                           <input type="text" id="station_w" name="station_w" class="form-control">
                        </div>
                     </div>


                  </div>
                  <div class="col-md-4">
                     <div class="row">
                        <div class="col-md-4">
                           <input type="text" id="num_h" name="num_h" class="form-control">
                        </div>
                        <div class="col-md-4">
                           <input type="text" id="num_m" name="num_m" class="form-control">
                        </div>
                        <div class="col-md-4">
                           <input type="text" id="num_w" name="num_w" class="form-control">
                        </div>
                     </div>

                  </div>
               </div>

            </td>


            <td> <input type="text" id="pr" name="pr" class="form-control"></td>
            <td> <input type="text" id="actual" name="actual" class="form-control"></td>


         </tr>

         </tbody>
      </table>

      <table style="margin-top: 50px;" class="table table-bordered">
         <thead>
         <tr>
            <th>اجمالي عينات الشهر</th>
            <th> عينات متصرفة</th>
            <th> عينات مرتجعة</th>
            <th> متوسط عينات الزيارة</th>


         </tr>

         </thead>
         <tbody>
         <tr>

            <td><input type="text" name="total_samples" class="form-control"></td>
            <td><input type="text" name="paid_samples" class="form-control"></td>
            <td><input type="text" name="back_samples" class="form-control"></td>
            <td><input type="text" name="average_samples" class="form-control"></td>
         </tr>

         </tbody>
      </table>

      <input type="submit" class="btn btn-primary" style="width: 250px; margin-bottom: 50px;">


   </form>


   <?php if(!$errors->any()): ?>
      <?php if(Session::has('message')): ?>
         <div class="alert alert-success" role="alert">
            <strong><?php echo e(Session::get('type')); ?> </strong> <?php echo e(Session::get('message')); ?>

         </div>
      <?php endif; ?>
   <?php else: ?>
      <div class="alert alert-danger" role="alert">
         <strong> Warning! </strong> please Check the error and  try submitting again.
      </div>
   <?php endif; ?>



</section>
<script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src='<?php echo e(asset('js/jquery-2.2.2.min.js')); ?>'></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" integrity="" crossorigin="anonymous"></script>
<script src="../js/jquery.nicescroll.min.js"></script>
<script  src="../js/myjs.js" type="text/javascript">  </script>
<script>
   $('#doc').click(function () {
       function myFunction() {
           var today = new Date();
           var month = today.getMonth();

           return (daysInMonth(month + 1, today.getFullYear()));
       }

       function daysInMonth(month,year) {
           return new Date(year, month, 0).getDate();
       }
       var sum=0;
      for(var i=1;i<=myFunction();i++)
      {
          if($('#doctors_pm'+i).val()!='')
          {
              sum += parseFloat($('#doctors_pm'+i).val());

          }


      }
       $('#doc').val(sum);
       $('#doctors_clinic_ac').click(function () {
           $('#doctors_clinic_ac').val(sum);
       });


   });


   $('#ph').click(function () {
       function myFunction() {
           var today = new Date();
           var month = today.getMonth();

           return (daysInMonth(month + 1, today.getFullYear()));
       }

       function daysInMonth(month,year) {
           return new Date(year, month, 0).getDate();
       }
       var sum=0;
       for(var i=1;i<=myFunction();i++)
       {
           if($('#pharma_pm'+i).val()!='')
           {
               sum += parseFloat($('#pharma_pm'+i).val());

           }


       }
       $('#ph').val(sum);
       $('#pharmacy_ac').click(function () {
           $('#pharmacy_ac').val(sum);
       });
   });

   $('#station_h').click(function () {
       function myFunction() {
           var today = new Date();
           var month = today.getMonth();

           return (daysInMonth(month + 1, today.getFullYear()));
       }

       function daysInMonth(month,year) {
           return new Date(year, month, 0).getDate();
       }
       var sum=0;
       for(var i=1;i<=myFunction();i++)
       {
           if($('#station_h_am'+i).val()!='')
           {
               sum += parseFloat($('#station_h_am'+i).val());

           }


       }
       $('#station_h').val(sum);
       $('#station_h_ac').click(function () {
           $('#station_h_ac').val(sum);
       });
   });

   $('#station_m').click(function () {
       function myFunction() {
           var today = new Date();
           var month = today.getMonth();

           return (daysInMonth(month + 1, today.getFullYear()));
       }

       function daysInMonth(month,year) {
           return new Date(year, month, 0).getDate();
       }
       var sum=0;
       for(var i=1;i<=myFunction();i++)
       {
           if($('#station_m_am'+i).val()!='')
           {
               sum += parseFloat($('#station_m_am'+i).val());

           }


       }
       $('#station_m').val(sum);
       $('#station_m_ac').click(function () {
           $('#station_m_ac').val(sum);
       });

   });

   $('#station_w').click(function () {
       function myFunction() {
           var today = new Date();
           var month = today.getMonth();

           return (daysInMonth(month + 1, today.getFullYear()));
       }

       function daysInMonth(month,year) {
           return new Date(year, month, 0).getDate();
       }
       var sum=0;
       for(var i=1;i<=myFunction();i++)
       {
           if($('#station_w_am'+i).val()!='')
           {
               sum += parseFloat($('#station_w_am'+i).val());

           }


       }
       $('#station_w').val(sum);
       $('#station_w_ac').click(function () {
           $('#station_w_ac').val(sum);
       });

   });


   $('#num_h').click(function () {
       function myFunction() {
           var today = new Date();
           var month = today.getMonth();

           return (daysInMonth(month + 1, today.getFullYear()));
       }

       function daysInMonth(month,year) {
           return new Date(year, month, 0).getDate();
       }
       var sum=0;
       for(var i=1;i<=myFunction();i++)
       {
           if($('#doctors_num_h_am'+i).val()!='')
           {
               sum += parseFloat($('#doctors_num_h_am'+i).val());

           }


       }
       $('#num_h').val(sum);
       $('#doctors_num_h_ac').click(function () {
           $('#doctors_num_h_ac').val(sum);
       });
   });

   $('#num_m').click(function () {
       function myFunction() {
           var today = new Date();
           var month = today.getMonth();

           return (daysInMonth(month + 1, today.getFullYear()));
       }

       function daysInMonth(month,year) {
           return new Date(year, month, 0).getDate();
       }
       var sum=0;
       for(var i=1;i<=myFunction();i++)
       {
           if($('#doctors_num_m_am'+i).val()!='')
           {
               sum += parseFloat($('#doctors_num_m_am'+i).val());

           }


       }
       $('#num_m').val(sum);
       $('#doctors_num_m_ac').click(function () {
           $('#doctors_num_m_ac').val(sum);
       });
   });


   $('#num_w').click(function () {
       function myFunction() {
           var today = new Date();
           var month = today.getMonth();

           return (daysInMonth(month + 1, today.getFullYear()));
       }

       function daysInMonth(month,year) {
           return new Date(year, month, 0).getDate();
       }
       var sum=0;
       for(var i=1;i<=myFunction();i++)
       {
           if($('#doctors_num_w_am'+i).val()!='')
           {
               sum += parseFloat($('#doctors_num_w_am'+i).val());

           }


       }
       $('#num_w').val(sum);
       $('#doctors_num_w_ac').click(function () {
           $('#doctors_num_w_ac').val(sum);
       });
   });


   $('#pr').click(function () {
       function myFunction() {
           var today = new Date();
           var month = today.getMonth();

           return (daysInMonth(month + 1, today.getFullYear()));
       }

       function daysInMonth(month,year) {
           return new Date(year, month, 0).getDate();
       }
       var sum=0;
       for(var i=1;i<=myFunction();i++)
       {
           if($('#egption_pranch'+i).val()!='')
           {
               sum += parseFloat($('#egption_pranch'+i).val());

           }


       }
       $('#pr').val(sum);
       $('#eg_pranch_ac').click(function () {
           $('#eg_pranch_ac').val(sum);
       });
   });


   $('#actual').click(function () {
       function myFunction() {
           var today = new Date();
           var month = today.getMonth();

           return (daysInMonth(month + 1, today.getFullYear()));
       }

       function daysInMonth(month,year) {
           return new Date(year, month, 0).getDate();
       }
       var sum=0;
       for(var i=1;i<=myFunction();i++)
       {
           if($('#actual_paid'+i).val()!='')
           {
               sum += parseFloat($('#actual_paid'+i).val());

           }


       }
       $('#actual').val(sum);
   });











</script>

</body>
</html>