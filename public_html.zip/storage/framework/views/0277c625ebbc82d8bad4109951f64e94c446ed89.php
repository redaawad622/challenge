<html>
<body>
<?php echo e($error); ?>

</body>
</html>