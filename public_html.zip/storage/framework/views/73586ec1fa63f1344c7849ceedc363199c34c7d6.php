<?php $__env->startSection('content'); ?>

    <div class="container">
        <!-- start Comparison of the sale by sector -->

        <div class="statistic  align-items-center bg-white has-shadow">
            <h3>Comparison of the sale by sector</h3>

            <form method="post" action="/Comparison" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="exampleFormControlFile1">choose picture</label>
                    <input type="file" class="form-control-file  <?php if ($errors->has('url')){echo 'is-invalid';} ?>" name="url" id="exampleFormControlFile1" required>
                    <div class="invalid-feedback">
                        <?php $__currentLoopData = $errors->get('url'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
            </form>

        </div>
        <!-- end Comparison of the sale by sector -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>