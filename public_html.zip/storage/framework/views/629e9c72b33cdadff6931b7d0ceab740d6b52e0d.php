<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Vactions</title>
      <link href="https://fonts.googleapis.com/css?family=Mirza" rel="stylesheet">
      <link href="../css/bootstrap.css" rel="stylesheet">
      <link href="../css/forms.css" rel="stylesheet">
      <link rel="stylesheet" href="../css/form/blackStyle-them.css">
      <link href="../css/font-awesome.css" rel="stylesheet">
      <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
      <![endif]-->
   </head>
   <body>
      <!--section setting option-->
      <section class="option-box">
         <div class="color-option">
            <h4>Color option</h4>
            <ul class="list-unstyled">
               <li style="background:#000" data-value="../css/form/blackStyle-them.css"></li>
               <li data-value="../css/form/pinkStyle-them.css"></li>
               <li data-value="../css/form/blueStyle-them.css"></li>
               <li data-value="../css/form/seaStyle-them.css"></li>
               <li data-value="../css/form/greenStyle-them.css"></li>
               <li data-value="../css/form/violetStyle-them.css"></li>
            </ul>
         </div>
         <i class="fa fa-gear fa-3x gear-ch"></i>
      </section>
      <section class="bod">
         <form action="vaction" method="post">
          <?php echo e(csrf_field()); ?>

            <div class="container-fluid">
               <hr>
               <div class="row">
                  <div class="col-md-3">
                     <div class="row">
                        <div class="col-md-2">
                           <h5 class="center  padding-t-lg"> م </h5>
                           <div class=" center padding-lg-s">
                              <span class=" bold">1</span>
                           </div>
                           
                        </div>
                        <div class="col-md-6">
                           <h5 class="center padding-t-lg"> الاسم </h5>
                           <div class="form-group">
                              <input type="text" name="name" class="form-control ">
                           </div>
                           
                        </div>
                        <div class="col-md-4">
                           <h5 class="center padding-t-lg"> الوظيفة </h5>
                           <div class="form-group">
                              <input type="text" name="job" class="form-control ">
                           </div>
                            
                        </div>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <h4 class="center"> الأجازات</h4>
                     <div class="row">
                        <div class="col-md-1">
                           <p class="center bold"> يناير </p>
                           <div class="form-group">
                              <input type="text" name="jan" class="form-control ">
                           </div>
                         </div>
                        <div class="col-md-1">
                           <p class="center bold"> فبراير </p>
                           <div class="form-group">
                              <input type="text" name="feb" class="form-control ">
                           </div>
                         </div>
                        <div class="col-md-1">
                           <p class="center bold"> مارس </p>
                           <div class="form-group">
                              <input type="text" name="marc" class="form-control ">
                           </div>
                         </div>
                        <div class="col-md-1">
                           <p class="center bold"> ابريل </p>
                           <div class="form-group">
                              <input type="text" name="abril" class="form-control ">
                           </div>
                         </div>
                        <div class="col-md-1">
                           <p class="center bold"> مايو </p>
                           <div class="form-group">
                              <input type="text" name="mai" class="form-control ">
                           </div>
                         </div>
                        <div class="col-md-1">
                           <p class="center bold"> يونيو </p>
                           <div class="form-group">
                              <input type="text" name="jun" class="form-control ">
                           </div>
                         </div>
                        <div class="col-md-1">
                           <p class="center bold"> يوليو </p>
                           <div class="form-group">
                              <input type="text" name="jul" class="form-control ">
                           </div>
                         </div>
                        <div class="col-md-1">
                           <p class="center bold"> أغسطس </p>
                           <div class="form-group">
                              <input type="text" name="aug" class="form-control ">
                           </div>
                         </div>
                        <div class="col-md-1">
                           <p class="center bold"> سبتمبر </p>
                           <div class="form-group">
                              <input type="text" name="sept" class="form-control ">
                           </div>
                         </div>
                        <div class="col-md-1">
                           <p class="center bold"> اكتوبر </p>
                           <div class="form-group">
                              <input type="text" name="oct" class="form-control ">
                           </div>
                         </div>
                        <div class="col-md-1">
                           <p class="center bold"> نوفمبر </p>
                           <div class="form-group">
                              <input type="text" name="nov" class="form-control ">
                           </div>
                        </div>
                        <div class="col-md-1">
                           <p class="center bold"> ديسمبر </p>
                           <div class="form-group">
                              <input type="text" name="dec" class="form-control ">
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <h4 class="center">الرصيد</h4>
                     <div class="row">
                        <div class="col-md-4">
                           <h4 class="center"> السنوية </h4>
                           <div class="form-group">
                              <input type="text" name="annual" class="form-control ">
                           </div>
                        </div>
                        <div class="col-md-4">
                           <h4 class="center"> المتصلة </h4>
                           <div class="form-group">
                              <input type="text" name="connected" class="form-control ">
                           </div>                
                        </div>
                        <div class="col-md-4">
                           <h4 class="center"> العارضة </h4>
                           <div class="form-group">
                              <input type="text" name="objection" class="form-control ">
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <hr>
            </div>
            <input type="submit"  class="btn btn-primary mr-3" value="ارسال">
         </form>
      </section>
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
      <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
      <script src="../js/jquery.nicescroll.min.js"></script>
      <script src="../js/myjs.js" type="text/javascript"></script>
   </body>
</html>