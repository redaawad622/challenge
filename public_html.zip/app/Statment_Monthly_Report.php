<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Statment_Monthly_Report extends Model
{
    //
}
