<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sumtion_monthly extends Model
{
    //
}
