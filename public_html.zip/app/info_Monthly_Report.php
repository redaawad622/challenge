<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class info_Monthly_Report extends Model
{
    //
}
