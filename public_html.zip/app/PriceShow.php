<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PriceShow extends Model
{
    //
}
