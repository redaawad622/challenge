<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Monthly_Plan extends Model
{
    //
}
